rm(list = ls())
options(stringsAsFactors = F)
library(doParallel) 
registerDoParallel(cores=detectCores())

#save(pbmc,file="0.6步结束后工作区所有文件  cells500   features500  未进行第二次标准化.Rdata")    #保存目前的工作区所有文件
load("0.6步结束后工作区所有文件  cells500   features500  未进行第二次标准化.Rdata")

library(limma)
library(Seurat)
library(dplyr)
library(magrittr)
library(CellChat)
library(patchwork)
library(celldex)
library(SingleR)


#细胞亚群人工注释 https://mp.weixin.qq.com/s/GE07VeDukx9jJuitM0lPsw
#5. 细胞注释
#5.1 识别每个类群的全部标记物
cluster_markers <- FindAllMarkers(object = pbmc, 
                                  test.use="wilcox" ,
                                  only.pos = TRUE,
                                  logfc.threshold = 0.25)  ##此步耗时较长，17:22开始  1.5小时左右
write.table(cluster_markers,file="cluster_markers cells500   features500  未进行第二次标准化.xls",sep="\t",row.names=F,quote=F)

# 读进来
cluster_markers <- read.table("cluster_markers cells500   features500  未进行第二次标准化.xls", header = TRUE)


#5.2 筛选每个cluster中表达前10的基因
# 筛选p_val<0.05的基因
all.markers =cluster_markers %>% dplyr::select(gene,everything()) %>% dplyr::filter(p_val<0.05)
#all.markers =cluster_markers %>% dplyr::select(gene,everything()) %>% dplyr::filter(p_val_adj<0.05)
#all.markers =cluster_markers %>% dplyr::select(gene,everything()) %>% dplyr::filter(avg_log2FC>2)
# 将avg_log2FC排名前10的基因筛选出来
top10 = all.markers %>% group_by(cluster) %>% top_n(n = 10, wt = avg_log2FC)
write.table(top10,file="各个cluster  top10  markers cells500   features500  未进行第二次标准化.xls",sep="\t",row.names=F,quote=F)
pdf(file="06.tsneHeatmap  各个cluster前10个基因热图.pdf",width=40,height=20)
DoHeatmap(object = pbmc, features = top10$gene) + NoLegend()   #使用了前十个基因进行绘制热图  ##有很多基因不存在，不懂为啥
dev.off()


top5 = all.markers %>% group_by(cluster) %>% top_n(n = 5, wt = avg_log2FC)
write.table(top5,file="各个cluster  top5  markers cells500   features500  未进行第二次标准化.xls",sep="\t",row.names=F,quote=F)
pdf(file="06.tsneHeatmap  各个cluster前5个基因热图.pdf",width=40,height=20)
DoHeatmap(object = pbmc, features = top5$gene) + NoLegend()   #使用了前十个基因进行绘制热图  ##有很多基因不存在，不懂为啥
dev.off()

top20 = all.markers %>% group_by(cluster) %>% top_n(n = 20, wt = avg_log2FC)
write.table(top20,file="各个cluster  top20  markers cells500   features500  未进行第二次标准化.xls",sep="\t",row.names=F,quote=F)
pdf(file="06.tsneHeatmap  各个cluster前20个基因热图.pdf",width=40,height=20)
DoHeatmap(object = pbmc, features = top20$gene) + NoLegend()   #使用了前十个基因进行绘制热图  ##有很多基因不存在，不懂为啥
dev.off()


top50 = all.markers %>% group_by(cluster) %>% top_n(n = 50, wt = avg_log2FC)
write.table(top50,file="各个cluster  top50  markers cells500   features500  未进行第二次标准化.xls",sep="\t",row.names=F,quote=F)
pdf(file="06.tsneHeatmap  各个cluster前50个基因热图.pdf",width=40,height=20)
DoHeatmap(object = pbmc, features = top50$gene) + NoLegend()   #使用了前十个基因进行绘制热图  ##有很多基因不存在，不懂为啥
dev.off()



#5.3 手动查找maker基因进行注释
#我们可以通过下面的数据库进行查找maker基因进行细胞注释。这里我们以CellMarker数据库为例进行演示。
#我们可以通过下面的数据库进行查找maker基因进行细胞注释。这里我们以CellMarker数据库为例进行演示。
#CellMarker数据库：https://panglaodb.se/index.html
#PanglaoDB数据库：https://panglaodb.se/index.html
#                 https://panglaodb.se/search.html



#####经过上述查询后现将细胞进行注释
#5.4 更改cluster名
celltype=read.table("cluster ann.txt",sep="\t",header=T)
pbmc@meta.data$celltype = "NA"
for(i in 1:nrow(celltype)){
  pbmc@meta.data[which(pbmc@meta.data$seurat_clusters == celltype$cluster[i]),'celltype'] <- celltype$celltype[i]}


# 提取只含AS的pbmc
pbmc_AS <- pbmc[, grep("^AS", colnames(pbmc@assays$RNA), value = TRUE)]
# 提取只含HC的pbmc
pbmc_HC <- pbmc[, grep("^HC", colnames(pbmc@assays$RNA), value = TRUE)]

# 统计各个细胞亚群的细胞数量
细胞统计_全部=data.frame(table(pbmc@meta.data[["celltype"]]))
细胞统计_AS=data.frame(table(pbmc_AS@meta.data[["celltype"]]))
细胞统计_HC=data.frame(table(pbmc_HC@meta.data[["celltype"]]))
# 将数据框输出为 Excel 文件
library(openxlsx)
write.xlsx(细胞统计_全部, "细胞统计_全部.xlsx")
write.xlsx(细胞统计_AS, "细胞统计_AS.xlsx")
write.xlsx(细胞统计_HC, "细胞统计_HC.xlsx")



####注意第6步是用什么方法进行聚类，是tsne聚类还是umap聚类，要对应好只运行下面其中一种即可

#tsne聚类
DimPlot(pbmc, reduction = "tsne",label = T)
DimPlot(pbmc, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类未注释（AS、HC全部）.pdf",width=8,height=6)
DimPlot(pbmc, reduction = "tsne",label = T)
dev.off()
pdf(file="07.tsne细胞分类细胞注释（AS、HC全部）.pdf",width=10,height=6)
DimPlot(pbmc, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 提取只含AS的pbmc
pbmc_AS <- pbmc[, grep("^AS", colnames(pbmc@assays$RNA), value = TRUE)]
# 提取只含HC的pbmc
pbmc_HC <- pbmc[, grep("^HC", colnames(pbmc@assays$RNA), value = TRUE)]



#AS的tsne聚类
DimPlot(pbmc_AS, reduction = "tsne",label = T)
DimPlot(pbmc_AS, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类未注释（AS）.pdf",width=8,height=6)
DimPlot(pbmc_AS, reduction = "tsne",label = T)
dev.off()
pdf(file="07.tsne细胞分类细胞注释（AS）.pdf",width=10,height=6)
DimPlot(pbmc_AS, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC, reduction = "tsne",label = T)
DimPlot(pbmc_HC, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类未注释（HC）.pdf",width=8,height=6)
DimPlot(pbmc_HC, reduction = "tsne",label = T)
dev.off()
pdf(file="07.tsne细胞分类细胞注释（HC）.pdf",width=10,height=6)
DimPlot(pbmc_HC, reduction = "tsne", group.by = "celltype",label = T)
dev.off()



#读取细胞注释信息
#cellAnn=read.table("07.all cellAnn cells500   features500  未进行第二次标准化.txt",sep="\t",header=F)
cellAnn=celltype
unique(cellAnn$celltype)
#获取细胞注释后的细胞类型名称
# 分别提取各种细胞的所有细胞



############### 提取Naive CD8+ T cell的pbmc############
Naive_CD8_T_cell <- "Naive CD8+ T cell"
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_Naive_CD8_T_cell <- subset(pbmc, subset = celltype == Naive_CD8_T_cell)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_Naive CD8+ T cell）.pdf",width=8,height=6)
DimPlot(pbmc_Naive_CD8_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取Naive CD8+ T cell的pbmc
pbmc_AS_Naive_CD8_T_cell <- pbmc_Naive_CD8_T_cell[, grep("^AS", colnames(pbmc_Naive_CD8_T_cell@assays$RNA), value = TRUE)]
# 在HC中提取Naive CD8+ T cell的pbmc
pbmc_HC_Naive_CD8_T_cell <- pbmc_Naive_CD8_T_cell[, grep("^HC", colnames(pbmc_Naive_CD8_T_cell@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_Naive_CD8_T_cell, reduction = "tsne",label = T)
DimPlot(pbmc_AS_Naive_CD8_T_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_Naive CD8+ T cell）.pdf",width=8,height=6)
DimPlot(pbmc_AS_Naive_CD8_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_Naive_CD8_T_cell, reduction = "tsne",label = T)
DimPlot(pbmc_HC_Naive_CD8_T_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_Naive CD8+ T cell）.pdf",width=8,height=6)
DimPlot(pbmc_HC_Naive_CD8_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()


unique(cellAnn$celltype)
############### 提取Th1_cell的pbmc############
Th1_cell <- "T helper1 (Th1) cell"
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_Th1_cell <- subset(pbmc, subset = celltype == Th1_cell)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_T helper1 (Th1) cell）.pdf",width=8,height=6)
DimPlot(pbmc_Th1_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取T helper1 (Th1) cell的pbmc
pbmc_AS_Th1_cell <- pbmc_Th1_cell[, grep("^AS", colnames(pbmc_Th1_cell@assays$RNA), value = TRUE)]
# 在HC中提取T helper1 (Th1) cell的pbmc
pbmc_HC_Th1_cell <- pbmc_Th1_cell[, grep("^HC", colnames(pbmc_Th1_cell@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_Th1_cell, reduction = "tsne",label = T)
DimPlot(pbmc_AS_Th1_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_T helper1 (Th1) cell）.pdf",width=8,height=6)
DimPlot(pbmc_AS_Th1_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_Th1_cell, reduction = "tsne",label = T)
DimPlot(pbmc_HC_Th1_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_T helper1 (Th1) cell）.pdf",width=8,height=6)
DimPlot(pbmc_HC_Th1_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()




unique(cellAnn$celltype)
############### 提取Natural_killer_cell的pbmc############
Natural_killer_cell <- "Natural killer cell"
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_Natural_killer_cell <- subset(pbmc, subset = celltype == Natural_killer_cell)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_Natural_killer_cell）.pdf",width=8,height=6)
DimPlot(pbmc_Natural_killer_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取Natural_killer_cell的pbmc
pbmc_AS_Natural_killer_cell <- pbmc_Natural_killer_cell[, grep("^AS", colnames(pbmc_Natural_killer_cell@assays$RNA), value = TRUE)]
# 在HC中提取Natural_killer_cell的pbmc
pbmc_HC_Natural_killer_cell <- pbmc_Natural_killer_cell[, grep("^HC", colnames(pbmc_Natural_killer_cell@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_Natural_killer_cell, reduction = "tsne",label = T)
DimPlot(pbmc_AS_Natural_killer_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_Natural_killer_cell）.pdf",width=8,height=6)
DimPlot(pbmc_AS_Natural_killer_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_Natural_killer_cell, reduction = "tsne",label = T)
DimPlot(pbmc_HC_Natural_killer_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_Natural_killer_cell）.pdf",width=8,height=6)
DimPlot(pbmc_HC_Natural_killer_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()



unique(cellAnn$celltype)
############### 提取Effector_CD8_memory_T_cell的pbmc############
Effector_CD8_memory_T_cell <- "Effector CD8+ memory T (Tem) cell"
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_Effector_CD8_memory_T_cell <- subset(pbmc, subset = celltype == Effector_CD8_memory_T_cell)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_Effector_CD8_memory_T_cell）.pdf",width=8,height=6)
DimPlot(pbmc_Effector_CD8_memory_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取Effector_CD8_memory_T_cell的pbmc
pbmc_AS_Effector_CD8_memory_T_cell <- pbmc_Effector_CD8_memory_T_cell[, grep("^AS", colnames(pbmc_Effector_CD8_memory_T_cell@assays$RNA), value = TRUE)]
# 在HC中提取Effector_CD8_memory_T_cell的pbmc
pbmc_HC_Effector_CD8_memory_T_cell <- pbmc_Effector_CD8_memory_T_cell[, grep("^HC", colnames(pbmc_Effector_CD8_memory_T_cell@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_Effector_CD8_memory_T_cell, reduction = "tsne",label = T)
DimPlot(pbmc_AS_Effector_CD8_memory_T_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_Effector_CD8_memory_T_cell）.pdf",width=8,height=6)
DimPlot(pbmc_AS_Effector_CD8_memory_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_Effector_CD8_memory_T_cell, reduction = "tsne",label = T)
DimPlot(pbmc_HC_Effector_CD8_memory_T_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_Effector_CD8_memory_T_cell）.pdf",width=8,height=6)
DimPlot(pbmc_HC_Effector_CD8_memory_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()



unique(cellAnn$celltype)
############### 提取M2_macrophage的pbmc############
M2_macrophage <- "M2 macrophage"
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_M2_macrophage <- subset(pbmc, subset = celltype == M2_macrophage)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_M2_macrophage）.pdf",width=8,height=6)
DimPlot(pbmc_M2_macrophage, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取M2_macrophage的pbmc
pbmc_AS_M2_macrophage <- pbmc_M2_macrophage[, grep("^AS", colnames(pbmc_M2_macrophage@assays$RNA), value = TRUE)]
# 在HC中提取M2_macrophage的pbmc
pbmc_HC_M2_macrophage <- pbmc_M2_macrophage[, grep("^HC", colnames(pbmc_M2_macrophage@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_M2_macrophage, reduction = "tsne",label = T)
DimPlot(pbmc_AS_M2_macrophage, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_M2_macrophage）.pdf",width=8,height=6)
DimPlot(pbmc_AS_M2_macrophage, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_M2_macrophage, reduction = "tsne",label = T)
DimPlot(pbmc_HC_M2_macrophage, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_M2_macrophage）.pdf",width=8,height=6)
DimPlot(pbmc_HC_M2_macrophage, reduction = "tsne", group.by = "celltype",label = T)
dev.off()



unique(cellAnn$celltype)
############### 提取CD1C_CD141_dendritic_cell的pbmc############
CD1C_CD141_dendritic_cell <- "CD1C-CD141- dendritic cell"
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_CD1C_CD141_dendritic_cell <- subset(pbmc, subset = celltype == CD1C_CD141_dendritic_cell)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_CD1C_CD141_dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_CD1C_CD141_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取CD1C_CD141_dendritic_cell的pbmc
pbmc_AS_CD1C_CD141_dendritic_cell <- pbmc_CD1C_CD141_dendritic_cell[, grep("^AS", colnames(pbmc_CD1C_CD141_dendritic_cell@assays$RNA), value = TRUE)]
# 在HC中提取CD1C_CD141_dendritic_cell的pbmc
pbmc_HC_CD1C_CD141_dendritic_cell <- pbmc_CD1C_CD141_dendritic_cell[, grep("^HC", colnames(pbmc_CD1C_CD141_dendritic_cell@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_CD1C_CD141_dendritic_cell, reduction = "tsne",label = T)
DimPlot(pbmc_AS_CD1C_CD141_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_CD1C_CD141_dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_AS_CD1C_CD141_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_CD1C_CD141_dendritic_cell, reduction = "tsne",label = T)
DimPlot(pbmc_HC_CD1C_CD141_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_CD1C_CD141_dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_HC_CD1C_CD141_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()



unique(cellAnn$celltype)
############### 提取Naive_CD4_T_cell的pbmc############
Naive_CD4_T_cell <- "Naive CD4+ T cell"
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_Naive_CD4_T_cell <- subset(pbmc, subset = celltype == Naive_CD4_T_cell)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_Naive_CD4_T_cell）.pdf",width=8,height=6)
DimPlot(pbmc_Naive_CD4_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取Naive_CD4_T_cell的pbmc
pbmc_AS_Naive_CD4_T_cell <- pbmc_Naive_CD4_T_cell[, grep("^AS", colnames(pbmc_Naive_CD4_T_cell@assays$RNA), value = TRUE)]
# 在HC中提取Naive_CD4_T_cell的pbmc
pbmc_HC_Naive_CD4_T_cell <- pbmc_Naive_CD4_T_cell[, grep("^HC", colnames(pbmc_Naive_CD4_T_cell@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_Naive_CD4_T_cell, reduction = "tsne",label = T)
DimPlot(pbmc_AS_Naive_CD4_T_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_Naive_CD4_T_cell）.pdf",width=8,height=6)
DimPlot(pbmc_AS_Naive_CD4_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_Naive_CD4_T_cell, reduction = "tsne",label = T)
DimPlot(pbmc_HC_Naive_CD4_T_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_Naive_CD4_T_cell）.pdf",width=8,height=6)
DimPlot(pbmc_HC_Naive_CD4_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()




unique(cellAnn$celltype)
############### 提取B_cell的pbmc############
B_cell <- "B cell"
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_B_cell <- subset(pbmc, subset = celltype == B_cell)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_B_cell）.pdf",width=8,height=6)
DimPlot(pbmc_B_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取B_cell的pbmc
pbmc_AS_B_cell <- pbmc_B_cell[, grep("^AS", colnames(pbmc_B_cell@assays$RNA), value = TRUE)]
# 在HC中提取B_cell的pbmc
pbmc_HC_B_cell <- pbmc_B_cell[, grep("^HC", colnames(pbmc_B_cell@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_B_cell, reduction = "tsne",label = T)
DimPlot(pbmc_AS_B_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_B_cell）.pdf",width=8,height=6)
DimPlot(pbmc_AS_B_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_B_cell, reduction = "tsne",label = T)
DimPlot(pbmc_HC_B_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_B_cell）.pdf",width=8,height=6)
DimPlot(pbmc_HC_B_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()



unique(cellAnn$celltype)
############### 提取Plasmacytoid_dendritic_cell的pbmc############
Plasmacytoid_dendritic_cell <- "Plasmacytoid dendritic cell"
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_Plasmacytoid_dendritic_cell <- subset(pbmc, subset = celltype == Plasmacytoid_dendritic_cell)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_Plasmacytoid_dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_Plasmacytoid_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取Plasmacytoid_dendritic_cell的pbmc
pbmc_AS_Plasmacytoid_dendritic_cell <- pbmc_Plasmacytoid_dendritic_cell[, grep("^AS", colnames(pbmc_Plasmacytoid_dendritic_cell@assays$RNA), value = TRUE)]
# 在HC中提取Plasmacytoid_dendritic_cell的pbmc
pbmc_HC_Plasmacytoid_dendritic_cell <- pbmc_Plasmacytoid_dendritic_cell[, grep("^HC", colnames(pbmc_Plasmacytoid_dendritic_cell@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_Plasmacytoid_dendritic_cell, reduction = "tsne",label = T)
DimPlot(pbmc_AS_Plasmacytoid_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_Plasmacytoid_dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_AS_Plasmacytoid_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_Plasmacytoid_dendritic_cell, reduction = "tsne",label = T)
DimPlot(pbmc_HC_Plasmacytoid_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_Plasmacytoid_dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_HC_Plasmacytoid_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()



unique(cellAnn$celltype)
############### 提取CD141_CLEC9A_dendritic_cell的pbmc############
CD141_CLEC9A_dendritic_cell <- "CD141+CLEC9A+ dendritic cell"
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_CD141_CLEC9A_dendritic_cell <- subset(pbmc, subset = celltype == CD141_CLEC9A_dendritic_cell)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_CD141_CLEC9A_dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_CD141_CLEC9A_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取CD141_CLEC9A_dendritic_cell的pbmc
pbmc_AS_CD141_CLEC9A_dendritic_cell <- pbmc_CD141_CLEC9A_dendritic_cell[, grep("^AS", colnames(pbmc_CD141_CLEC9A_dendritic_cell@assays$RNA), value = TRUE)]
# 在HC中提取CD141_CLEC9A_dendritic_cell的pbmc
pbmc_HC_CD141_CLEC9A_dendritic_cell <- pbmc_CD141_CLEC9A_dendritic_cell[, grep("^HC", colnames(pbmc_CD141_CLEC9A_dendritic_cell@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_CD141_CLEC9A_dendritic_cell, reduction = "tsne",label = T)
DimPlot(pbmc_AS_CD141_CLEC9A_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_CD141_CLEC9A_dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_AS_CD141_CLEC9A_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_CD141_CLEC9A_dendritic_cell, reduction = "tsne",label = T)
DimPlot(pbmc_HC_CD141_CLEC9A_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_CD141_CLEC9A_dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_HC_CD141_CLEC9A_dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()



unique(cellAnn$celltype)
############### 提取所有T cell亚群的pbmc############
T_cell <- c("Naive CD4+ T cell","Naive CD8+ T cell","Effector CD8+ memory T (Tem) cell","T helper1 (Th1) cell")
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_T_cell <- subset(pbmc, subset = celltype == T_cell)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_ T_cell）.pdf",width=8,height=6)
DimPlot(pbmc_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取T_cell的pbmc
pbmc_AS_T_cell <- pbmc_T_cell[, grep("^AS", colnames(pbmc_T_cell@assays$RNA), value = TRUE)]
# 在HC中提取T_cell的pbmc
pbmc_HC_T_cell <- pbmc_T_cell[, grep("^HC", colnames(pbmc_T_cell@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_T_cell, reduction = "tsne",label = T)
DimPlot(pbmc_AS_T_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_ T_cell）.pdf",width=8,height=6)
DimPlot(pbmc_AS_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_T_cell, reduction = "tsne",label = T)
DimPlot(pbmc_HC_T_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_ T_cell）.pdf",width=8,height=6)
DimPlot(pbmc_HC_T_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()


unique(cellAnn$celltype)
############### 提取所有dendritic cell亚群的pbmc############
Dendritic_cell <- c("CD1C-CD141- dendritic cell","Plasmacytoid dendritic cell","CD141+CLEC9A+ dendritic cell")
# 使用 Seurat 的子集函数来提取特定细胞类型的子集
pbmc_Dendritic_cell <- subset(pbmc, subset = celltype == Dendritic_cell)

#AS、HC全部的tsne聚类
pdf(file="07.tsne细胞分类细胞注释（AS、HC_ Dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_Dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

# 在AS中提取Dendritic_cell的pbmc
pbmc_AS_Dendritic_cell <- pbmc_Dendritic_cell[, grep("^AS", colnames(pbmc_Dendritic_cell@assays$RNA), value = TRUE)]
# 在HC中提取Dendritic_cell的pbmc
pbmc_HC_Dendritic_cell <- pbmc_Dendritic_cell[, grep("^HC", colnames(pbmc_Dendritic_cell@assays$RNA), value = TRUE)]

#AS的tsne聚类
DimPlot(pbmc_AS_Dendritic_cell, reduction = "tsne",label = T)
DimPlot(pbmc_AS_Dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（AS_ Dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_AS_Dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()

#HC的tsne聚类
DimPlot(pbmc_HC_Dendritic_cell, reduction = "tsne",label = T)
DimPlot(pbmc_HC_Dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
pdf(file="07.tsne细胞分类细胞注释（HC_ Dendritic_cell）.pdf",width=8,height=6)
DimPlot(pbmc_HC_Dendritic_cell, reduction = "tsne", group.by = "celltype",label = T)
dev.off()







#将全部的细胞注释结果、分类后的细胞注释结果输出
write.table(clusters,file="07.clusters cells500   features500  未进行第二次标准化.txt",quote=F,sep="\t",col.names=F)
write.table(celltype, file="07.celltype cells500   features500  未进行第二次标准化.txt",quote=F,sep="\t",col.names=F)
write.table(pbmc@meta.data,file="07.all cellAnn cells500   features500  未进行第二次标准化.txt",quote=F,sep="\t",col.names=F)

#准备monocle分析需要的文件   准备细胞轨迹分析需要的文件
#行名为基因名、列名为样品名的matrix文件
monocle.matrix=as.matrix(pbmc@assays$RNA@data)    #此步耗内存
monocle.matrix[1:6,1:6 ]
dim(monocle.matrix)
class(monocle.matrix)
#write.table(monocle.matrix, file = "07.monocleMatrix.txt", sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)##这一步耗时较长、耗内存较大。
#因输出txt文件较大，输出及后面读取耗时较久，尝试保存R文件
save(monocle.matrix,file="07.monocleMatrix  cells500   features500  未进行第二次标准化.Rdata")
#load("07.monocleMatrix  cells500   features500  未进行第二次标准化.Rdata")

#样品文件，样品类型，哪个细胞来自哪个样品
monocle.sample=as.matrix(pbmc@meta.data)
monocle.sample[1:6,1:6 ]
write.table(monocle.sample, file = "07.monocleSample  cells500   features500  未进行第二次标准化.txt", sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)

#基因文件
monocle.geneAnn=data.frame(gene_short_name = row.names(monocle.matrix), row.names = row.names(monocle.matrix))
head(monocle.geneAnn)
write.table(monocle.geneAnn,file="07.monocleGene  cells500   features500  未进行第二次标准化.txt",sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)   #所有基因文件    #不用输出了，直接接着做细胞轨迹图

#Mark基因文件
all.markers =cluster_markers %>% dplyr::select(gene,everything()) %>% dplyr::filter(p_val_adj<0.05)
all.markers =cluster_markers %>% dplyr::select(gene,everything()) %>% dplyr::filter(avg_log2FC>2)
sig.markers07=as.data.frame(all.markers)
sig.markers07[1:6,1:7 ]
#sig.markers07$gene=rownames(sig.markers07)  #新增一列，列名为gene，值等于行名
sig.markers07[1:6,1:7]
write.table(sig.markers07, file = "07.monocleMarkers  cells500   features500  未进行第二次标准化.txt", sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)


class(celltype)
head(celltype)
write.table(celltype, file = "07.monocleClusterAnn  cells500   features500  未进行第二次标准化.txt", sep = "\t", quote = FALSE, row.names = F, col.names = F)


#以下几行代码用于细胞互作、细胞通讯分析
#save(pbmc,file="pbmc 细胞通讯使用cells500   features500  未进行第二次标准化.Rdata")    #保存，用于后续细胞通讯互作分析
#load("pbmc 细胞通讯使用cells500   features500  未进行第二次标准化.Rdata")
#head(pbmc@meta.data)
#meta.data需要准备的文件=data.frame(pbmc@meta.data)
#head(meta.data需要准备的文件)
#write.table(meta.data需要准备的文件, file = "meta.data需要准备的文件cells500   features500  未进行第二次标准化.txt", sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)



celltype_marker=read.table("celltype_marker.txt", sep="\t",header = TRUE)

gene=as.character(celltype_marker$marker)



pdf(file="各分类细胞marker表达情况（AS、HC）.pdf",width=14,height=5)
DotPlot(object = pbmc, features = gene, group.by = "celltype")  +theme(axis.text.x = element_text(angle = 90,vjust = 0.5, hjust=0.5))
dev.off()


DotPlot(object = pbmc, features = gene, group.by = "celltype")


gene

print(duplicated(cell))


th=theme(axis.text.x = element_text(angle = 45,vjust = 0.5, hjust=0.5))  
myeloids = list(
  Mac=c("C1QA","C1QB","C1QC","SELENOP","RNASE1","DAB2","LGMN","PLTP","MAF","SLCO2B1"),
  mono=c("VCAN","FCN1","CD300E","S100A12","EREG","APOBEC3A","STXBP2","ASGR1","CCR2","NRG1"),
  neutrophils =  c("FCGR3B","CXCR2","SLC25A37","G0S2","CXCR1","ADGRG3","PROK2","STEAP4","CMTM2" ),
  pDC = c("GZMB","SCT","CLIC3","LRRC26","LILRA4","PACSIN1","CLEC4C","MAP1A","PTCRA","C12orf75"),
  DC1 = c("CLEC9A","XCR1","CLNK","CADM1","ENPP1","SNX22","NCALD","DBN1","HLA-DOB","PPY"),
  DC2=c( "CD1C","FCER1A","CD1E","AL138899.1","CD2","GPAT3","CCND2","ENHO","PKIB","CD1B"),
  DC3 =  c("HMSD","ANKRD33B","LAD1","CCR7","LAMP3","CCL19","CCL22","INSM1","TNNT2","TUBB2B")
)
p <- DotPlot(pbmc, features = myeloids,
             assay='RNA' ,group.by = 'celltype' )  +th

p
ggsave(plot=p, filename="check_myeloids_marker_by_celltype.pdf") 





Monocyte=c("CD14","ITGAM","FCGR3A","LYZ","S100A8")
#巨噬细胞Macrophage
Macrophage=c("CD68","CD163")
#Macro1_C1QC 种特定类型的巨噬细胞，可能与C1QC蛋白相关
Macro1_C1QC=c("CD68","C1QC")
#Macro2_CXCL3一种特定类型的巨噬细胞，可能与CXCL3蛋白相关。
Macro2_CXCL3=c("CD68","CXCL3")
#Macro3_FOS一种特定类型的巨噬细胞，可能与FOS蛋白相关。
Macro3_FOS=c("CD68","FOS")
#Macro4_CCL20一种特定类型的巨噬细胞，可能与CCL20蛋白相关。
Macro4_CCL20=c("CD68","CCL20")
#Mono1_CD14-S100A8单核细胞的一个亚型，可能表达CD14和S100A8等蛋白。
Mono1_CD14_S100A8=c("CD68","CD14	","S100A8")
#Mono2_CD14-ITGA4单核细胞的另一个亚型，可能表达CD14和ITGA4等蛋白。
Mono2_CD14_ITGA4=c("CD68","CD14	","ITGA4")
#Mono3_FCGR3A单核细胞的另一个亚型，可能表达FCGR3A蛋白。
Mono3_FCGR3A=c("CD68","FCGR3A")   #可能这行代码需要修改6
#cDC1_CLEC9A一种树突状细胞类型，可能表达CLEC9A蛋白。
cDC1_CLEC9A="CLEC9A"
#cDC2_CD1C一种树突状细胞类型，可能表达CD1C蛋白。
cDC2_CD1C="CD1C"
#pDC浆细胞树突状细胞，是一种树突状细胞类型，通常涉及抗病毒免疫反应。
pDC="LILRA4"
#Mast肥大细胞，是一种免疫细胞，通常涉及过敏反应和炎症。
Mast="TPSAB1"

##M1型巨噬细胞、M2型巨噬细胞


markers <- c(Monocyte,Macrophage,Macro1_C1QC,Macro2_CXCL3,Macro3_FOS,Macro4_CCL20,
             Mono1_CD14_S100A8,Mono2_CD14_ITGA4,Mono3_FCGR3A,cDC1_CLEC9A,cDC2_CD1C,pDC,Mast)



#点图
#scRNA=as.matrix(pbmc@assays$RNA@data)
DotPlot(pbmc, features = unique(markers),group.by = "seurat_clusters")+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
ggsave("celltype_marker_dot.pdf",width = 9.5,height = 6)


new.cluster.ids <- c("Endothelial_cell","T_cell",
                     "T_cell","Endothelial_cell","Macrophage","B_cell",
                     "Kupffer_cell","B_cell","DC","Kupffer_cell",
                     "Kupffer_cell","Cholangiocyte","Hepatocyte",
                     "Plasma_B_cell","Endothelial_cell",
                     "HSC")
scRNA@meta.data$celltype<- scRNA@meta.data$seurat_clusters
levels(scRNA@meta.data$celltype) <- new.cluster.ids#将celltype确定










markers_df <- FindMarkers(object = pbmc, ident.1 = 8, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 8.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 8.Rdata")
#FindMarkers函数找到在第8个细胞簇中具有显著差异表达的基因。ident.1参数指定了要比较的细胞簇的标识符，min.pct参数指定了在至少多少百分比的细胞中表达的基因才被考虑。

print(x = head(markers_df))
markers_genes =  rownames(head(x = markers_df, n = 5))
VlnPlot(object = pbmc, features =markers_genes,log =T )
FeaturePlot(object = pbmc, features=markers_genes )

markers_df <- FindMarkers(object = pbmc, ident.1 = 1, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 1.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 1.Rdata")

markers_df <- FindMarkers(object = pbmc, ident.1 = 2, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 2.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 2.Rdata")

markers_df <- FindMarkers(object = pbmc, ident.1 = 3, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 3.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 3.Rdata")

markers_df <- FindMarkers(object = pbmc, ident.1 = 4, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 4.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 4.Rdata")

markers_df <- FindMarkers(object = pbmc, ident.1 = 5, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 5.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 5.Rdata")


markers_df <- FindMarkers(object = pbmc, ident.1 = 6, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 6.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 6.Rdata")

markers_df <- FindMarkers(object = pbmc, ident.1 = 7, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 7.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 7.Rdata")


markers_df <- FindMarkers(object = pbmc, ident.1 = 9, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 9.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 9.Rdata")


markers_df <- FindMarkers(object = pbmc, ident.1 = 10, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 10.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 10.Rdata")


markers_df <- FindMarkers(object = pbmc, ident.1 = 11, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 11.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 11.Rdata")

markers_df <- FindMarkers(object = pbmc, ident.1 = 12, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 12.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 12.Rdata")

markers_df <- FindMarkers(object = pbmc, ident.1 = 13, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 13.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 13.Rdata")

markers_df <- FindMarkers(object = pbmc, ident.1 = 14, min.pct = 0.25)  #耗时，约41分钟
#save(pbmc,file="FindMarkers后  ident.1 = 14.Rdata")    #保存目前的工作区所有文件
load("FindMarkers后  ident.1 = 14.Rdata")








print(x = head(markers_df))
markers_genes =  rownames(head(x = markers_df, n = 5))
VlnPlot(object = sce, features =markers_genes,log =T )
FeaturePlot(object = sce, features=markers_genes )












pbmc@assays$RNA@data[1:6,1:6]
rownames(pbmc@assays$RNA@data)

Macrophage=c("CD68","CD163")  #Macrophage 
pbmc_Macrophage <- pbmc[rownames(pbmc@assays$RNA@data) %in% Macrophage,]


#Macro1_C1QC 种特定类型的巨噬细胞，可能与C1QC蛋白相关
Macro1_C1QC=c("CD68","C1QC")
pbmc_Macro1_C1QC <- pbmc[rownames(pbmc) %in% Macro1_C1QC,]

show(pbmc_Macro1_C1QC@assays$RNA@data)

a=data.frame(pbmc_Macro1_C1QC@assays$RNA@data)
library(writexl)
write_xlsx(a, path = "a.xlsx")


#Macro2_CXCL3一种特定类型的巨噬细胞，可能与CXCL3蛋白相关。
Macro2_CXCL3=c("CD68","CXCL3")
pbmc_Macro2_CXCL3 <- pbmc[rownames(pbmc) %in% Macro2_CXCL3,]


#Macro3_FOS一种特定类型的巨噬细胞，可能与FOS蛋白相关。
Macro3_FOS=c("CD68","FOS")
pbmc_Macro2_CXCL3 <- pbmc[rownames(pbmc) %in% Macro2_CXCL3,]


#Macro4_CCL20一种特定类型的巨噬细胞，可能与CCL20蛋白相关。
Macro4_CCL20=c("CD68","CCL20")
pbmc_Macro2_CXCL3 <- pbmc[rownames(pbmc) %in% Macro2_CXCL3,]
#Mono1_CD14-S100A8单核细胞的一个亚型，可能表达CD14和S100A8等蛋白。
Mono1_CD14_S100A8=c("CD68","CD14	","S100A8")
pbmc_Macro2_CXCL3 <- pbmc[rownames(pbmc) %in% Macro2_CXCL3,]
#Mono2_CD14-ITGA4单核细胞的另一个亚型，可能表达CD14和ITGA4等蛋白。
Mono2_CD14_ITGA4=c("CD68","CD14	","ITGA4")
pbmc_Macro2_CXCL3 <- pbmc[rownames(pbmc) %in% Macro2_CXCL3,]
#Mono3_FCGR3A单核细胞的另一个亚型，可能表达FCGR3A蛋白。
Mono3_FCGR3A=c("CD68","FCGR3A")   #可能这行代码需要修改6
pbmc_Macro2_CXCL3 <- pbmc[rownames(pbmc) %in% Macro2_CXCL3,]
#cDC1_CLEC9A一种树突状细胞类型，可能表达CLEC9A蛋白。
cDC1_CLEC9A="CLEC9A"
pbmc_Macro2_CXCL3 <- pbmc[rownames(pbmc) %in% Macro2_CXCL3,]
#cDC2_CD1C一种树突状细胞类型，可能表达CD1C蛋白。
cDC2_CD1C="CD1C"
pbmc_Macro2_CXCL3 <- pbmc[rownames(pbmc) %in% Macro2_CXCL3,]
#pDC浆细胞树突状细胞，是一种树突状细胞类型，通常涉及抗病毒免疫反应。
pDC="LILRA4"
pbmc_Macro2_CXCL3 <- pbmc[rownames(pbmc) %in% Macro2_CXCL3,]
#Mast肥大细胞，是一种免疫细胞，通常涉及过敏反应和炎症。
Mast="TPSAB1"
pbmc_Macro2_CXCL3 <- pbmc[rownames(pbmc) %in% Macro2_CXCL3,]




