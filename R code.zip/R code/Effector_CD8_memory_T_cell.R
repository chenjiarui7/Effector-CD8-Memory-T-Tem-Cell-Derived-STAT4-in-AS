rm(list = ls())
options(stringsAsFactors = F)
library(doParallel) 
registerDoParallel(cores=detectCores())

library(limma)


#读取表达矩阵
load("AS HC表达矩阵 cells500   features大于500小于10000  percent.mt小于10  未进行二次标准化.Rdata")
class(expre)
dim(expre)



#读取细胞注释信息
cellAnn=read.table("07.all cellAnn cells500   features500  未进行第二次标准化.txt",sep="\t",header=T)
unique(cellAnn$cell)
#获取细胞注释后的细胞类型名称
# 分别提取各种细胞的所有细胞
Effector_CD8_memory_T_cell <- cellAnn$Lable[cellAnn$cell == "Effector CD8+ memory T (Tem) cell"]

# 提取Effector_CD8_memory_T_cell的表达矩阵
expre_Effector_CD8_memory_T_cell=expre[ ,Effector_CD8_memory_T_cell]

#################下面进行差异分析############
########对Effector_CD8_memory_T_cell细胞做差异分析#####
#load("AS HC表达矩阵 cells500   features大于500小于10000  percent.mt小于10  未进行二次标准化.Rdata")
expre=expre_Effector_CD8_memory_T_cell  #对Effector_CD8_memory_T_cell细胞做差异分析
#将样本进行分组
x <- colnames(expre) #将列名提取出来并等于x
x
xx=stringr::str_detect(x,"AS") #判断x里的每一个值是否含有AS，并将判断结果返回xx
xx 
table(xx)  #对xx进行计数
xxx <- paste(xx=stringr::str_detect(x,"AS"))  #将上一步的判断结果名为xxx
xxx
table(xxx)
xxxx=substring(xxx,1,2) #提取判断结果（TRUE和FALSE）的前两个字符，需要做这一步是因为得到的TRUE和FALSE不能直接作为列名
xxxx
table(xxxx)
colnames(expre)
colnames(expre) <- xxxx  
group_list=unlist(colnames(expre))

#DEG by limma
#BiocManager::install("limma", version = "3.8")
library(limma)
#expre    #dat2为标准化后取对数的表达矩阵
expre[1:4,1:4]
suppressMessages(library(limma))
design<- model.matrix(~0+factor(group_list))  #这一步是将样本进行分组 ，根据group_list的分组，把它变成一个矩阵# model.matrix函数是limma包里的，不需要去理解
colnames(design)=levels(factor(group_list))
rownames(design)=colnames(expre)
design
table(design[,1]) #查看design即分组信息，实验组合对照组各有多少个
contrast.matrix<-makeContrasts(paste0(unique(group_list),collapse = "-"),levels = design)
contrast.matrix<-makeContrasts("TR-FA",levels = design)
contrast.matrix
#这个矩阵声明，我们要把Control组跟Vemurafenib进行差异分析比较
## step1
fit <- lmFit(expre,design)   #耗时耗内存
##step2
fit2<-contrasts.fit(fit,contrast.matrix) #这一步很重要
fit2<- eBayes(fit2) ##default no trend
## eBayes() with trend=TRUE
## step3
tempOutput=topTable(fit2,coef=1,n=Inf)
nrDEG=na.omit(tempOutput)
#write.csv(nrDEG2,"limma_noted,results.csv",quote=F)
dim(nrDEG)
head(nrDEG)
nrDEG$gene <- rownames(nrDEG)
head(nrDEG)
# 删除线粒体基因，框,MT开头的是线粒体基因
nrDEG <- nrDEG[!grepl("^MT", rownames(nrDEG)), ]
dim(nrDEG)

##下面几步为后续GO、KEGG分析做准备
#BiocManager::install("org.Hs.eg.db")
library("org.Hs.eg.db") #引用包
head(nrDEG)
rt=nrDEG[,c("gene","logFC")]
genes=as.vector(rt[,1])
entrezIDs <- mget(genes, org.Hs.egSYMBOL2EG, ifnotfound=NA)    #找出基因对应的id
entrezIDs <- as.character(entrezIDs)
out=cbind(rt,entrezID=entrezIDs)
nrDEG=cbind(nrDEG,entrezID=entrezIDs)
library(openxlsx)
write.xlsx(nrDEG, "Effector_CD8_memory_T_cell AS v HC 总的DEGs.xlsx", rownames = TRUE)
#write.table(nrDEG,file="Effector_CD8_memory_T_cell AS v HC 总的DEGs.xls",sep="\t",quote=F) #输出总DEGs


#提取关键差异基因
dat=nrDEG
head(dat)
DEGs <- dat[dat$adj.P.Val< 0.01 & abs(dat$logFC) >2,]
dim(DEGs)                 #此步说明，之前的表达矩阵不能进行第二次标准化。需重新导入表达矩阵进行分析
write.xlsx(DEGs, "Effector_CD8_memory_T_cell AS v HC DEGs,adj P＜0.01,FC＞2.xlsx", rownames = TRUE)
#write.table(DEGs,file="Effector_CD8_memory_T_cell AS v HC DEGs,P＜0.01,FC＞2.xls",sep="\t",quote=F)


#提取关键差异基因
dat=nrDEG
head(dat)
DEGs <- dat[dat$P.Value< 0.05 & abs(dat$logFC) >1,]
dim(DEGs)                 #此步说明，之前的表达矩阵不能进行第二次标准化。需重新导入表达矩阵进行分析
write.xlsx(DEGs, "Effector_CD8_memory_T_cell AS v HC DEGs,P Value＜0.05,FC＞1.xlsx", rownames = TRUE)
#write.table(DEGs,file="Effector_CD8_memory_T_cell AS v HC DEGs,P＜0.01,FC＞2.xls",sep="\t",quote=F)



#####GO分析
#install.packages("colorspace")
#install.packages("stringi")
#install.packages("ggplot2")
#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("DOSE")
#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("clusterProfiler")  #如果此行安装不了就尝试使用下面一行
#BiocManager::install("clusterProfiler", site_repository = "http://mirrors.ustc.edu.cn/bioc/")
#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("enrichplot")

library("clusterProfiler")
library("org.Hs.eg.db")
library("enrichplot")
library("ggplot2")
library(colorspace)

#rt=read.table("id.txt",sep="\t",header=T,check.names=F)           #读取id.txt文件
rt=DEGs  #进行GO、KEGG分析的基因条件P Value＜0.05,FC＞1
dim(rt)
rt=rt[is.na(rt[,"entrezID"])==F,]        #去除基因id为NA的基因
dim(rt)
gene=rt$entrezID

#GO富集分析
kk <- enrichGO(gene = gene,OrgDb = org.Hs.eg.db, pvalueCutoff =0.05,qvalueCutoff = 0.05, ont="all",readable =T)  #耗时1-2分钟
write.xlsx(kk, "Effector_CD8_memory_T_cell GO结果,P Value＜0.05,FC＞1.xlsx", rownames = TRUE)
#write.table(kk,file="GO.txt",sep="\t",quote=F,row.names = F)                 #保存富集结果

#柱状图
pdf(file="Effector_CD8_memory_T_cell GO结果,P Value＜0.05,FC＞1 柱状图.pdf",width = 18,height = 10)
barplot(kk, drop = TRUE, showCategory =10,split="ONTOLOGY") + facet_grid(ONTOLOGY~., scale='free')  #根据p值排序前10个
dev.off()

#气泡图
pdf(file="Effector_CD8_memory_T_cell GO结果,P Value＜0.05,FC＞1 气泡图.pdf",width = 18,height = 10)
dotplot(kk,showCategory = 10,split="ONTOLOGY") + facet_grid(ONTOLOGY~., scale='free')
dev.off()



#install.packages("digest")
#install.packages("GOplot")
library(GOplot)
library(digest)

#ego=read.table("GO.txt", header = T,sep="\t",check.names=F)      #读取GO富集结果文件
ego=kk
go=data.frame(Category = "All",ID = ego$ID,Term = ego$Description, Genes = gsub("/", ", ", ego$geneID), adj_pval = ego$p.adjust)

#读取基因的logFC文件
#id.fc <- read.table("id.txt", header = T,sep="\t",check.names=F)
id.fc=rt[,c("logFC","gene","entrezID")]    #进行GO、KEGG分析的基因条件P Value＜0.05,FC＞1
genelist <- data.frame(ID = id.fc$gene, logFC = id.fc$logFC)
row.names(genelist)=genelist[,1]


class(go)
class(genelist)
circ <- circle_dat(go, genelist)
termNum = 4                                     #限定term数目，根据p值排序前多少个term
geneNum = nrow(genelist)                        #限定基因数目

chord <- chord_dat(circ, genelist[1:geneNum,], go$Term[1:termNum])
pdf(file="Effector_CD8_memory_T_cell GO结果,P Value＜0.05,FC＞1  圆圈图.pdf",width = 15,height = 15)
GOChord(chord, 
        space = 0.001,           #基因之间的间距
        gene.order = 'logFC',    #按照logFC值对基因排序
        gene.space = 0.25,       #基因名跟圆圈的相对距离
        gene.size = 5,           #基因名字体大小 
        border.size = 0.1,       #线条粗细
        process.label = 6)       #term字体大小
dev.off()

termCol <- c("#223D6C","#D20A13","#FFD121","#088247","#58CDD9","#7A142C","#5D90BA","#431A3D","#91612D","#6E568C","#E0367A","#D8D155","#64495D","#7CC767")
pdf(file="Effector_CD8_memory_T_cell GO结果,P Value＜0.05,FC＞1  分类图cluster.pdf",width = 12,height = 12)
GOCluster(circ.gsym, 
          go$Term[1:termNum], 
          lfc.space = 0.2,                   #倍数跟树间的空隙大小
          lfc.width = 1,                     #变化倍数的圆圈宽度
          term.col = termCol[1:termNum],     #自定义term的颜色
          term.space = 0.2,                  #倍数跟term间的空隙大小
          term.width = 1)                    #富集term的圆圈宽度
dev.off()          



#####KEGG分析
library("clusterProfiler")
library("org.Hs.eg.db")
library("enrichplot")
library("ggplot2")
library(openxlsx)
#rt=read.table("id.txt",sep="\t",header=T,check.names=F)       #读取id.txt文件
head(DEGs)
rt_kegg=DEGs[,c("gene","logFC","entrezID")]
rt_kegg=rt_kegg[is.na(rt_kegg[,"entrezID"])==F,]                             #去除基因id为NA的基因
gene=rt_kegg$entrezID


#kegg富集分析
kk_kegg <- enrichKEGG(gene = gene, organism = "hsa", pvalueCutoff =0.05, qvalueCutoff =0.05)   #富集分析  此步需要联网  注意调整电脑时间为自动更新时间

write.xlsx(kk_kegg, "Effector_CD8_memory_T_cell KEGG ID结果,P Value＜0.05,FC＞1.xlsx", rownames = TRUE)
write.table(kk_kegg,file = "Effector_CD8_memory_T_cell_keggId.txt", sep="\t",quote=F,, row.names = FALSE)         #
#write.table(kk_kegg,file="KEGGId.txt",sep="\t",quote=F,row.names = F)                          #保存富集结果

#柱状图
pdf(file="Effector_CD8_memory_T_cell KEGG结果,P Value＜0.05,FC＞1  柱状图.pdf",width = 18,height = 10)
barplot(kk_kegg, drop = TRUE, showCategory = 30)
dev.off()

#气泡图
pdf(file="Effector_CD8_memory_T_cell KEGG结果,P Value＜0.05,FC＞1  气泡图.pdf",width = 18,height = 10)
dotplot(kk_kegg, showCategory = 30)
dev.off()



##########下面绘制圆圈图、分类图
#install.packages("digest")
#install.packages("GOplot")
library(GOplot)
#读取基因的logFC文件
#id.fc <- read.table("id.txt", header = T,sep="\t",check.names=F)
id.fc_kegg=rt_kegg
write.table(id.fc_kegg,file = "Effector_CD8_memory_T_cell_id.txt", sep="\t",quote=F,, row.names = FALSE)





#################运行完上面的代码后，就到处理perl语音进行ID转gene symbol，
#################将Effector_CD8_memory_T_cell_id.txt、Effector_CD8_memory_T_cell_keggId.txt两个文件复制到桌面KEGGID文件夹
#########运行完perl后,将Effector_CD8_memory_T_cell_kegg.txt文件拷贝到当前目录，然后继续运行下面代码



library(GOplot)
ego_kegg=read.table("Effector_CD8_memory_T_cell_kegg.txt", header = T,sep="\t",check.names=F)      #读取kegg富集结果文件
#go_kegg=data.frame(Category = "All",ID = ego_kegg$ID,Term = ego_kegg$Description, gene = gsub("/", ", ", ego_kegg$geneID), adj_pval = ego_kegg$p.adjust)
go_kegg=data.frame(Category = "All",ID = ego_kegg$ID,Term = ego_kegg$Description, Genes = gsub("/", ", ", ego_kegg$geneID), adj_pval = ego_kegg$p.adjust)

#读取基因的logFC文件
id.fc_kegg <- read.table("Effector_CD8_memory_T_cell_id.txt", header = T,sep="\t",check.names=F)
genelist_kegg <- data.frame(gene = id.fc_kegg$gene, logFC = id.fc_kegg$logFC)
genelist_kegg <- data.frame(ID = id.fc_kegg$gene, logFC = id.fc_kegg$logFC)
row.names(genelist_kegg)=genelist_kegg[,1]

circ_kegg <- circle_dat(go_kegg, genelist_kegg)

termNum = 4                                     #限定term数目
geneNum = nrow(genelist_kegg)                        #限定基因数目

chord_kegg <- chord_dat(circ_kegg, genelist_kegg[1:geneNum,], go_kegg$Term[1:termNum])
pdf(file="Effector_CD8_memory_T_cell KEGG结果 圆圈图,P Value＜0.05,FC＞1  圆圈图.pdf",width = 20,height = 20)
GOChord(chord_kegg, 
        space = 0.001,           #基因之间的间距
        gene.order = 'logFC',    #按照logFC值对基因排序
        gene.space = 0.25,       #基因名跟圆圈的相对距离
        gene.size = 5,           #基因名字体大小 
        border.size = 0.1,       #线条粗细
        process.label = 8)       #term字体大小
dev.off()


#绘制特定KEGG通路的圆圈图
termNum <- 5  # 选择4个通路
selected_pathways <- c(5, 7, 13, 15, 32)  # 选择第5、7、13和15条通路

# 构建选定通路的 chord 数据
selected_chord <- chord_dat(circ_kegg, genelist_kegg[1:geneNum,], go_kegg$Term[selected_pathways[1:termNum]])

# 绘制圆圈图
pdf(file="Effector_CD8_memory_T_cell KEGG结果 圆圈图,P Value＜0.05,FC＞1  圆圈图  特定通路.pdf", width = 20, height = 20)
GOChord(selected_chord, 
        space = 0.005,        #基因之间的间距
        gene.order = 'logFC', #按照logFC值对基因排序
        gene.space = 0.2,    #基因名跟圆圈的相对距离
        gene.size = 7,        #基因名字体大小 
        border.size = 0.1,    #线条粗细
        process.label = 10)    #term字体大小
dev.off()



KEGGnum=c(5,7)
geneNum = nrow(genelist_kegg)                        #限定基因数目
chord_kegg <- chord_dat(circ_kegg, genelist_kegg[KEGGnum,], go_kegg$Term[KEGGnum])
pdf(file="Effector_CD8_memory_T_cell KEGG结果 圆圈图,P Value＜0.05,FC＞1  圆圈图   特定KEGG通路的圆圈图.pdf",width = 20,height = 20)
GOChord(chord_kegg, 
        space = 0.001,           #基因之间的间距
        gene.order = 'logFC',    #按照logFC值对基因排序
        gene.space = 0.25,       #基因名跟圆圈的相对距离
        gene.size = 5,           #基因名字体大小 
        border.size = 0.1,       #线条粗细
        process.label = 8)       #term字体大小
dev.off()







termCol <- c("#223D6C","#D20A13","#FFD121","#088247","#58CDD9","#7A142C","#5D90BA","#431A3D","#91612D","#6E568C","#E0367A","#D8D155","#64495D","#7CC767")
pdf(file="Effector_CD8_memory_T_cell KEGG结果 分类cluster图,P Value＜0.05,FC＞1  分类图cluster.pdf",width = 15,height = 15)
GOCluster(circ.gsym, 
          go_kegg$Term[1:termNum], 
          lfc.space = 0.2,                   #倍数跟树间的空隙大小
          lfc.width = 1,                     #变化倍数的圆圈宽度
          term.col = termCol[1:termNum],     #自定义term的颜色
          term.space = 0.2,                  #倍数跟term间的空隙大小
          term.width = 1)                    #富集term的圆圈宽度
dev.off()          











#######提取高表达与低表达前10个基因绘制热图
#提取高表达、低表达前10个基因
# 提取logFC值最大的10个基因
top_10_max_DEGs <- head(DEGs[order(-DEGs$logFC), ], 10)
#top_10_max_DEGs_genes=c(as.character(row.names(top_10_max_DEGs)))  #转换成文字
# 提取logFC值最小的10个基因
top_10_min_DEGs <- head(DEGs[order(DEGs$logFC), ], 10)
#top_10_min_DEGs_genes=c(as.character(row.names(top_10_min_DEGs)))  #转换成文字
#将高表达前10与低表达前10个基因合并
高低表达前10基因=c(top_10_max_DEGs_genes,top_10_min_DEGs_genes)



##加载绘图需要的R包
library(ggplot2) ##绘图使用
library(ggprism) ##设置主题私用
library(ggrepel) ##给火山图加标签使用
#install.packages("ggprism")


#---3.对上调、下调基因赋色
#以P.Value <0.05和logFC > 2定义上调或下调基因，并对其赋色。
color <- rep("#999999",nrow(nrDEG))
color[nrDEG$P.Value <0.05 & nrDEG$logFC > 1] <- "#66A61E"
color[nrDEG$P.Value <0.05 & nrDEG$logFC < -1] <- "#FC4E07"

#---4.绘制火山图
plot(nrDEG$logFC, # 使用 nrDEG$logFC 作为 x 坐标轴的数据
     -log10(nrDEG$P.Value), # 使用 -log10(nrDEG$P.Value) 作为 y 坐标轴的数据
     pch = 16, # 设置散点的样式为小圆点
     cex = 2, # 设置散点的大小为默认大小的两倍
     xlim = c(-16,16), # 设置 x 坐标轴范围为 -10 到 10
     ylim = c(0,100), # 设置 y 坐标轴范围为 0 到 35
     col = color, # 设置散点的颜色为预定义的 color 变量
     frame.plot = T, # 给图形添加边框
     xlab = "logFC", # 设置 x 坐标轴的标签为 "log2FC"
     ylab = "-log10(P.Value)", # 设置 y 坐标轴的标签为 "-log10(P.Value)"
     cex.axis = 1.5, # 设置坐标轴刻度标签的大小为默认大小的1.5倍
     cex.lab = 1.5)+ # 设置轴标签的大小为默认大小的1.5倍
  abline(h = -log10(0.05),lwd = 3, lty = 3)+  #设置水平参考线
  abline(v = c(-2,2),lwd = 3, lty = 3)  #设置垂直参考线
legend(x = 6, y = 35, legend = c("Down","None","Up"), 
       bty = "y", # 去除边框
       pch = 19,cex = 1, # 设置点的样式和大小
       x.intersp = 1, # 设置字与点之间的距离；
       y.intersp = 1, # 设置点与点的高度差，相当于行距；
       col = c("#66A61E","#999999","#FC4E07"))
text(nrDEG$logFC, # 在 x 坐标轴为 nrDEG$logFC 的位置添加文本
     -log10(nrDEG$P.Value), # 在 y 坐标轴为 -log10(nrDEG$pvalue) 的位置添加文本
     labels = nrDEG$gene_label, # 使用 nrDEG$gene_label 作为文本标签
     adj = c(0, 1.5), # 调整文本位置的相对偏移量为 (0, 1.5)
     cex = 0.8, # 设置文本的缩放因子为默认大小的 0.8 倍
     col = color2) # 设置文本的颜色为预定义的 color2 变量



#---7.分别为要显示的上调、下调基因名的文字定义颜色（添加标签）：
color2 = c()
color2[which(nrDEG$labe1 == "Up")] = "#66A61E" #上调基因字体显示颜色
color2[which(nrDEG$label == "Down")] = "#FC4E07" #下调基因字体显示颜色

#---8.指定显示基因名，自己指定即可
mygene <- 高低表达前10基因 
#为显示的基因添加一个label用于显示基因的名字
nrDEG$gene_label <- ifelse(nrDEG$gene %in% mygene, nrDEG$gene, "")
#查看nrDEG
head(nrDEG)



#---9.火山图添加基因名字，显示出来
text(nrDEG$logFC, # 在 x 坐标轴为 nrDEG$logFC 的位置添加文本
     -log10(nrDEG$P.Value), # 在 y 坐标轴为 -log10(nrDEG$pvalue) 的位置添加文本
     labels = nrDEG$gene_label, # 使用 nrDEG$gene_label 作为文本标签
     adj = c(0, 1.5), # 调整文本位置的相对偏移量为 (0, 1.5)
     cex = 0.8, # 设置文本的缩放因子为默认大小的 0.8 倍
     col = color2) # 设置文本的颜色为预定义的 color2 变量






# 显示火山图
pdf(file="火山图Effector_CD8_memory_T_cell高表达、低表达各前10个基因火山图 .pdf",width=8,height=6)
print(volcano_plot)
dev.off()









#读取全部细胞全部基因表达矩阵
load("AS HC表达矩阵 cells500   features大于500小于10000  percent.mt小于10  未进行二次标准化.Rdata")
class(expre)
dim(expre)
expre=as.matrix(expre)
dim(expre)
expre[1:6,1:6]

#读取细胞注释信息
cellAnn=read.table("07.all cellAnn cells500   features500  未进行第二次标准化.txt",sep="\t",header=T)
unique(cellAnn$cell)
#获取细胞注释后的细胞类型名称
# 分别提取各种细胞的所有细胞
Effector_CD8_memory_T_cell <- cellAnn$Lable[cellAnn$cell == "B cell"]

# 提取Effector_CD8_memory_T_cell的表达矩阵
expre_Effector_CD8_memory_T_cell=expre[ ,Effector_CD8_memory_T_cell]
dim(expre_Effector_CD8_memory_T_cell)

#提取高低表达前10个共20个基因的表达矩阵
dat <- expre_Effector_CD8_memory_T_cell[高低表达前10基因, , drop = FALSE]  # drop = FALSE 保持结果为矩阵格式


#前10基因画热图
#dat=read.csv('前10DEGs热图表达谱数据.csv',row.names=1,header=TRUE)
#dat=exprs(a)
dim(dat)  #看dat有多少行，有多少列
dat[1:4,1:4]  #看一下矩阵里面数据结构，以确保可以进行下一步做相关性
M=cor(dat)   #进行相关性分析  
library(pheatmap)
#Heatmap(dat)
pdf(file="热图Effector_CD8_memory_T_cell高表达、低表达各前10个基因热图 .pdf",width=8,height=6)
pheatmap::pheatmap(dat,show_rownames=T,show_colnames=T, cluster_row =TRUE)
dev.off()

pdf(file="热图Effector_CD8_memory_T_cell高表达、低表达各前10个基因  相关性热图 .pdf",width=8,height=6)
pheatmap::pheatmap(M)  #看了热图后发现相关性挺好的，现在就是要把临床信息加上去即可
dev.off()


#下面三步就是把临床分组信息加上去
tmp=data.frame(group_list)  #将分组信息转为一个数据框并命名为tmp。g=，这个是什么意思？
rownames(tmp)=colnames(M)  #将tmp的行名等于M的列名
pdf(file="热图Effector_CD8_memory_T_cell高表达、低表达各前10个基因  添加临床信息 .pdf",width=8,height=6)
pheatmap::pheatmap(M,annotation_col = tmp)  #将对热图的每一列进行注释，注释信息为tmp的信息
dev.off()
#tmp等于分组信息，tmp的行名等于M的列名，对M进行画热图，热图的列进行注释，注释信息为tmp，而tmp是分组，即rbc、rbn、normal。
###上面这三部是一个循环，需要不断阅读理解才能理解得过去
#第7题完毕！










