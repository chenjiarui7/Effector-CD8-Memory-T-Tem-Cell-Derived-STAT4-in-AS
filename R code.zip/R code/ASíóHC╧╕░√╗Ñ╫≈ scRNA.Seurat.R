rm(list = ls())
options(stringsAsFactors = F)
library(doParallel) 
registerDoParallel(cores=detectCores())


library(patchwork)
#library(limma)
library(Seurat)
#library(dplyr)
#library(magrittr)
library(CellChat)
#library(patchwork)
#library(celldex)
#library(SingleR)
  

#save(pbmc,file="0.7步后pbmc  cells500   features500  未进行第二次标准化.Rdata")    #保存
load("pbmc 细胞通讯使用cells500   features500  未进行第二次标准化.Rdata")
#save(pbmc_HC,file="0.7步后pbmc_HC  cells500   features500  未进行第二次标准化.Rdata")    #保存
#load("0.7步后pbmc_HC  cells500   features500  未进行第二次标准化.Rdata")



#准备monocle分析需要的文件   准备细胞轨迹分析需要的文件
#行名为基因名、列名为样品名的matrix文件
monocle.matrix=as.matrix(pbmc@assays$RNA@data)    #此步耗内存
monocle.matrix[1:6,1:6 ]
dim(monocle.matrix)
class(monocle.matrix)
#write.table(monocle.matrix, file = "07.monocleMatrix.txt", sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)##这一步耗时较长、耗内存较大。
#因输出txt文件较大，输出及后面读取耗时较久，尝试保存R文件
#save(monocle.matrix,file="07.monocleMatrix_As  cells500   features500  未进行第二次标准化.Rdata")
#load("07.monocleMatrix_As  cells500   features500  未进行第二次标准化.Rdata")



###############下面几行代码为细胞轨迹做准备的文件，不用运行##################
#样品文件，样品类型，哪个细胞来自哪个样品
monocle.sample=as.matrix(pbmc@meta.data)
monocle.sample[1:6,1:6 ]
write.table(monocle.sample, file = "07.monocleSample_AS  cells500   features500  未进行第二次标准化.txt", sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)

#基因文件
monocle.geneAnn=data.frame(gene_short_name = row.names(monocle.matrix), row.names = row.names(monocle.matrix))
head(monocle.geneAnn)
write.table(monocle.geneAnn,file="07.monocleGene_AS  cells500   features500  未进行第二次标准化.txt",sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)   #所有基因文件    #不用输出了，直接接着做细胞轨迹图

#Mark基因文件
sig.markers07=as.data.frame(sig.markers)
sig.markers07[1:6,1:7 ]
sig.markers07$gene=rownames(sig.markers07)  #新增一列，列名为gene，值等于行名
sig.markers07[1:6,1:7]
write.table(sig.markers07, file = "07.monocleMarkers  cells500   features500  未进行第二次标准化.txt", sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)


class(celltype)
head(celltype)
write.table(celltype, file = "07.monocleClusterAnn  cells500   features500  未进行第二次标准化.txt", sep = "\t", quote = FALSE, row.names = F, col.names = F)
###############上面几行代码为细胞轨迹做准备的文件，不用运行##################

#以下几行代码用于细胞互作、细胞通讯分析
#save(pbmc,file="pbmc 细胞通讯使用cells500   features500  未进行第二次标准化.Rdata")    #保存，用于后续细胞通讯互作分析
#load("pbmc 细胞通讯使用cells500   features500  未进行第二次标准化.Rdata")
head(pbmc@meta.data)
meta.data需要准备的文件=data.frame(pbmc@meta.data)
#head(meta.data需要准备的文件)
#write.table(meta.data需要准备的文件, file = "meta.data需要准备的文件cells500   features500  未进行第二次标准化.txt", sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)


#Step1. 构建cellchat对象
#pbmc3k里的seurat_annotations有一些NA注释，过滤掉
#data.input = pbmc@assays$RNA@data        #获取单细胞表达矩阵
#   @符号用于从 Seurat 对象中提取特定的属性或数据,在这种情况下,它将用于从 pbmc3k对象中提取数据。
#   assays$RNA：这部分代码是用于选择 Seurat 对象中的某个特定的 assay（分析）。
#   在这里，assays 是一个包含不同分析数据的列表，而 $RNA 表示您正在选择与RNA数据相关的 assay。
#   通常，单细胞RNA测序数据存储在 Seurat 对象的 RNA assay 中。
#   data：一旦选择了正确的 assay，data 用于从 assay 中提取实际的基因表达数据。
#   这行代码的目的是从 pbmc3k 对象中提取其RNA数据，将其存储在 data.input 变量中，以便在后续的分析中使用。
#   这是一个常见的操作，用于准备单细胞RNA测序数据以进行后续的分析和可视化。
#class(data.input)
#head(data.input)[1:6,1:6]
#write.csv(data.input, file = "data.input总的文件 细胞通讯使用cells500   features500  未进行第二次标准化.csv", row.names = FALSE)
#save(data.input,file="data.input总的文件 细胞通讯使用_AS cells500   features500  未进行第二次标准化.Rdata")    #保存，用于后续细胞通讯互作分析
load("data.input总的文件 细胞通讯使用 cells500   features500  未进行第二次标准化.Rdata")
#data.input=data.input总的文件
head(data.input)[1:6,1:6]


#meta.data=read.table(("meta.data需要准备的文件cells500   features500  未进行第二次标准化.txt"))
meta.data=meta.data需要准备的文件
#meta.data =  pbmc3k@meta.data   #获取细胞注释信息
#    pbmc3k：pbmc3k 是您的 Seurat 对象的名称，包含了单细胞RNA测序数据以及与每个细胞相关的元信息。
#    @ 符号用于从 Seurat 对象中提取特定的属性或数据。
#    @meta.data：meta.data是一个变量，它包含了 Seurat 对象中的元信息。这部分代码表示您要从 pbmc3k 对象中提取元信息并将其存储在 meta.data 变量中。
#    这行代码的目的是将 pbmc3k 对象中的元信息提取并存储在名为 meta.data 的新变量中，以便在后续的分析中使用。
#    元信息通常包括细胞的标签、细胞类型、样本信息、质量控制信息等，这些信息对于单细胞RNA测序数据的分析和可视化非常重要。
#class(meta.data)     ##"dgCMatrix" 是一种用于表示稀疏矩阵（Sparse Matrix）的数据类型，通常在单细胞RNA测序数据中用于存储基因表达数据，因为这些数据通常非常稀疏（大多数元素为零）。
head(meta.data)
#print(colnames(meta.data))
#colnames(meta.data)=c("orig.ident", "nCount_RNA", "nFeature_RNA", "percent.mt", "RNA_snn_res.0.5", "seurat_clusters", "celltype")
#print(colnames(meta.data))
#write.csv(meta.data, file = "meta.data1.csv", row.names = T)  #输出查看数据的形式

meta.data = meta.data[!is.na(meta.data$celltype),]
##  meta.data是一个变量，它包含了 Seurat 对象中的元信息。通常，元信息包括有关每个单细胞的附加信息，如细胞类型、样本来源、质量控制信息等。
#   meta.data$celltype：这部分代码是在元信息中的一个特定列（列名为 "celltype"）上进行操作。它表示您要对这个列中的数据进行处理。
#   !is.na(...)：这是一个逻辑条件，表示 "不是缺失值"。也就是说，它会检查指定列中的值是否不是缺失值（NA）。
#   [...]：这部分代码用于从元信息中筛选符合条件的行。
#   综合起来，这行代码的目的是从 meta.data 中删除那些在 "celltype" 列中具有缺失值（NA）的行，从而对元信息进行了筛选，只保留了具有有效注释的行。这种操作通常用于清理和准备单细胞RNA测序数据的元信息，以便后续分析。
#write.csv(meta.data, file = "meta.data需要准备的文件.csv", row.names = T)

dim(data.input)
data.input = data.input[,row.names(meta.data)]
dim(data.input)
##   这行代码用于子集化或筛选 data.input 中的数据，以匹配 meta.data 中的行名（row names）。
#    data.input：这是一个数据对象，通常是一个数据框或矩阵，包含了您的主要数据。这是您希望对其进行操作的数据集。
#    [, row.names(meta.data)]：这部分代码表示了如何对 data.input 进行操作。在 R 中，方括号 [ ] 用于提取或操作数据的子集。
#    在这里：row.names(meta.data) 用于获取 meta.data 数据框中的行名，通常这些行名唯一标识了每个观测值或样本。
#    [, ...] 表示您正在使用这些行名来选择 data.input 中的特定行。
#    整个操作的目的是将 data.input 中的行子集化，只保留那些在 meta.data 表中存在的行。
#    这种操作通常用于确保主要数据集与元信息数据集的行名完全匹配，以便在数据分析中进行进一步的操作，例如合并或关联两个数据集。在这种情况下，只保留与元信息数据中匹配的观测值，以确保数据一致性。
class(data.input)
dim(data.input)
# head(data.input)   ##这个描述告诉您有一个6行、2638列的稀疏矩阵，它的数据类型是 'dgCMatrix'，用于表示具有大量零元素的数据，这在处理大规模数据集时非常有用。




length(meta.data$celltype)
unique_categories <- unique(meta.data$celltype)   # 使用unique()函数查看不同类别
num_categories <- length(unique_categories)   # 统计不同类别的个数
cat("不同类别：", paste(unique_categories, collapse = ", "), "\n")  # 打印结果
cat("列 'celltype' 中的不同类别个数：", num_categories, "\n")     # 打印结果
levels(factor(meta.data$celltype))
#设置因子水平
meta.data$celltype = factor(meta.data$celltype,
                                      levels = c("B cell","CD141+CLEC9A+ dendritic cell","CD1C-CD141- dendritic cell",
                                                  "Effector CD8+ memory T (Tem) cell","M2 macrophage",
                                                 "Naive CD4+ T cell", "Naive CD8+ T cell","Natural killer cell",
                                                 "Plasmacytoid dendritic cell","T helper1 (Th1) cell"))
##   这行代码的目的是将 meta.data 数据框中的 celltype 列的内容转换为因子，并指定了这个因子的水平，以确保该列的数据被正确地解释为离散的细胞类型或分类数据。
#    这通常用于准备数据以进行后续的分析和可视化，尤其在单细胞RNA测序数据分析中，确定细胞类型是一个重要的步骤。
celltype=factor(meta.data$celltype)
### 1.2 Create a CellChat object
cellchat <- createCellChat(object = data.input, 
                           meta = meta.data, 
                           group.by = "celltype")
#   createCellChat：这是一个函数，属于 "CellChat" 包，用于创建用于细胞间通信分析的对象。
#   object：这是一个参数，通常包含了单细胞RNA测序的基因表达数据。在这里，您的 data.input 变量被传递给 object 参数，因此它包含了用于分析的基因表达数据。
#   meta：这是另一个参数，通常包含了与每个单细胞相关的元信息。在这里，您的 meta.data 变量被传递给 meta 参数，以提供关于每个细胞的信息，如细胞类型、样本来源等。
#   group.by：这是参数，指定了用于将细胞分组或分类的元信息列的名称。在这里，"celltype" 被传递给 group.by 参数，因此分析将根据该列的信息进行细胞分组。
#   总之，这段代码的目的是使用 "CellChat" 包中的 createCellChat 函数，将单细胞RNA测序数据和相关的元信息整合到一个 CellChat 对象中，以进行细胞间通信的分析。
#    这种分析通常用于探索不同细胞类型之间的相互作用和通信，以深入了解单细胞水平的细胞间关系。
# class(cellchat)


levels(cellchat@idents)

### 1.3 可在cellchat对象的meta插槽中添加表型信息
# 添加meta.data信息
cellchat <- addMeta(cellchat, meta = meta.data)

# 设置默认的labels
levels(cellchat@idents) # show factor levels of the cell labels
cellchat <- setIdent(cellchat, ident.use = "celltype") 
groupSize <- as.numeric(table(cellchat@idents)) # number of cells in each cell group
#   table(cellchat@idents)：这部分代码使用 table() 函数来计算 CellChat 对象中不同细胞分组（idents）的数量。
#   cellchat@idents 是 CellChat 对象中包含细胞分组信息的部分。table() 函数将计算每个不同分组中的成员数量。
#   as.numeric(...)：这部分代码用于将计算结果转换为数值（numeric），以确保结果以数字形式存储。
#  综合起来，这行代码的作用是计算并存储每个细胞分组的大小或成员数量，以便后续分析或可视化。

#Step2. 加载CellChatDB数据库
### 1.4 加载CellChat受配体数据库
CellChatDB <- CellChatDB.human # use CellChatDB.mouse if running on mouse data
#  这行代码是用于从 "CellChat" 包中加载人类（human）的 CellChat 数据库（CellChatDB），并将其存储在名为 CellChatDB 的变量中。
showDatabaseCategory(CellChatDB)

# Show the structure of the database
dplyr::glimpse(CellChatDB$interaction)
#   dplyr::glimpse：这是一个函数调用，使用了 dplyr 包中的 glimpse 函数，它用于显示数据框或数据集的摘要信息，包括列名、列类型和前几行数据。
#   CellChatDB$interaction：这部分代码是访问 CellChatDB 中的 interaction 数据。通常，CellChatDB 包含了有关细胞间通信的数据，包括交互信息。
#   这行代码的目的是使用 glimpse 函数查看 CellChatDB 中的交互数据的摘要信息，以了解这些数据的结构、列名和数据类型。这有助于您在后续的数据分析和可视化中了解如何使用交互数据。

# use a subset of CellChatDB for cell-cell communication analysis
#CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling") # use Secreted Signaling
CellChatDB.use <- CellChatDB # simply use the default CellChatDB只需使用默认的CellChatDB
cellchat@DB <- CellChatDB.use
#  将 CellChatDB.use 中的数据赋给 cellchat 对象的 DB 部分，以更新 cellchat 对象的数据库。

#Step3. 对表达数据进行预处理
### 1.5 对表达数据进行预处理，用于细胞间通讯分析
# subset the expression data of signaling genes for saving computation cost
#install.packages("future")
library(future)
cellchat <- subsetData(cellchat) # This step is necessary even if using the whole database
#  这行代码的目的是使用 subsetData 函数来对 cellchat 对象中的数据进行筛选，可能是根据特定的条件、细胞类型、通信通路或其他标准。
#future::plan("multiprocess", workers = 1) # do parallel  #这行代码不是用来干嘛的，不用也可以？
#  这行代码是用于设置并行计算计划（parallel computing plan）的，使用了 R 语言中的 future 包。具体含义如下：
#  future::plan("multiprocess", workers = 1): 这一行代码指示 R 在后续的计算中使用多进程（multiprocess）并行计算计划。并行计算允许同时处理多个任务，以提高计算效率。
#  workers = 1: 这部分代码指定了并行计划中的工作进程数。在这里，将工作进程数设置为1，这意味着将使用一个单一的进程来执行并行计算。这似乎有点矛盾，因为并行计算通常旨在同时处理多个任务。但在这个特定设置下，将使用单一进程来执行并行任务。
#  总之，这行代码实际上没有启用多进程并行计算，因为 workers 参数设置为1，这将导致任务按照顺序执行，而不是并行执行。如果您希望利用多进程并行计算的潜力，您可以将 workers 参数设置为大于1的值，以指定同时执行的工作进程数量。这有助于加速计算，特别是在涉及大规模数据处理时。
#  future::plan("multicore", workers = 1)  #multicore"：使用多核 CPU 来并行执行任务。这适用于多核计算机。



#class(cellchat)
#list(cellchat)

#class(cellchat@data)
#data检测=data.frame(cellchat@data)

cellchat <- identifyOverExpressedGenes(cellchat)
#  identifyOverExpressedGenes属于 "CellChat" 包的一个函数，用于执行识别细胞间通信中过度表达基因的操作。
#  细胞间通信涉及到不同细胞类型之间的信号传递，其中特定基因在通信过程中可能会过度表达，即在某些细胞类型中表达水平显著高于其他细胞类型。
#>Error in genes.de[[i]] : 下标出界
#查找原因：表达矩阵是否存在缺失值
#sum(is.na(data.input)) > 0   #检测发现未存在缺失值
#sum(is.na(meta.data)) > 0   #检测发现未存在缺失值


cellchat <- identifyOverExpressedInteractions(cellchat)
#   识别细胞间通信中过度表达的相互作用（interactions）

# project gene expression data onto PPI (Optional: when running it, USER should set `raw.use = FALSE` in the function `computeCommunProb()` in order to use the projected data)
# cellchat <- projectData(cellchat, PPI.human)




#Part II：细胞-细胞通讯网络的推断
#Step4. 计算通讯概率，推断细胞通讯网络
#对于population. size参数的解读：是否考虑所有测序细胞中每组细胞的比例，
#population. size = FALSE：如果分析分选富集的单细胞，以消除潜在的人为因素细胞群的大小。
#population. size = TRUE，如果分析非分选富集的单细胞转录组，原因是丰富的细胞群往往比稀少的细胞群发送集体更强的信号。
cellchat <- computeCommunProb(cellchat,population.size = F)    #此步耗时较长
# Filter out the cell-cell communication if there are only few number of cells in certain cell groups
cellchat <- filterCommunication(cellchat, min.cells = 10)
#  filterCommunication：这是一个函数，属于 "CellChat" 包，用于执行筛选细胞间通信结果的操作。
#  min.cells = 10：这是一个参数，指定了要保留的细胞间通信结果的最小细胞数量。在这里，设置为 10，表示只保留那些在至少10个细胞中发生的通信结果。


#Step5. 提取预测的细胞通讯网络为data frame    #这一步提取不出来就不理了
### cellchat取子集
barcode.use = sample(row.names(cellchat@meta),100)
#从 cellchat 对象的元信息中随机抽样选择 100 个细胞的行名，这些行名可以用于后续的分析或可视化
barcode.use
class(barcode.use)
cellchat.subset = subsetCellChat(cellchat,cells.use = barcode.use)  #这行代码出错不懂为啥
#  根据 barcode.use 中的条形码列表，从原始的 cellchat 对象中创建一个子集 CellChat 对象，该子集对象仅包含您选择的特定细胞的数据。
#  这有助于在细胞间通信分析中聚焦于特定的细胞群体或细胞类型，以便更深入地研究其通信过程。
head(cellchat@meta)
data.input[1:6,1:6]


#获取所有的配受体对以及其通讯概率
df.net <- subsetCommunication(cellchat)
head(df.net)
write_xlsx(df.net, path = "df.net获取所有的配受体对以及其通讯概率(AS、HC).xlsx")

#以通路为单位提取通讯信息
df.pathway = subsetCommunication(cellchat,slot.name = "netP")
#install.packages("writexl")
library(writexl)
# 假设数据框名为df，将其保存为df.pathway.xlsx
write_xlsx(df.pathway, path = "df.pathway以通路为单位提取通讯信息(AS、HC).xlsx")


df.net1 <- subsetCommunication(cellchat, sources.use = c(1,2), targets.use = c(4,5)) 
#提取包含来自细胞组 1、2 到细胞组 4、5 的细胞-细胞通信数据
#sources.use = c(1,2) 指定了源细胞的子集，这意味着你想要筛选出从第 1 和第 2 个细胞发出的通信。
#targets.use = c(4,5) 指定了目标细胞的子集，这表示你希望筛选出发送到第 4 和第 5 个细胞的通信。
head(df.net1)
levels(cellchat@idents)
#(1,2)细胞分别是"B_cell"、"GMP"，(4,5)细胞分别是"Monocyte"、"NK_cell"。


df.net2 <- subsetCommunication(cellchat, sources.use = c(1), targets.use = c(2,3))
head(df.net2)
levels(cellchat@idents)
#这里的**source.use = c(1)**指的是B_cell，2和3分别对应GMP和MEP：

df.net3 <- subsetCommunication(cellchat, signaling = c("MIF", "MHC-I")) 
#提供了通过信号分子 MIF 和 MHC-I 介导的推测细胞间通信。
head(df.net3)


#Step6. 在信号通路水平推断细胞通讯
#CellChat通过汇总与每个信号通路相关的所有配体-受体相互作用的通讯概率，计算信号通路层面的通讯概率。
#注意：推断出的每个配体-受体对的细胞间通讯网络和每个信号通路分别存储在' net '和' netP '插槽中
cellchat <- computeCommunProbPathway(cellchat)
head(cellchat@net)
cellchat_net=data.frame(cellchat@net)
library(openxlsx)
write.xlsx(cellchat_net, "cellchat_net在信号通路水平推断细胞通讯(AS、HC).xlsx", row.names = TRUE)
head(cellchat@netP)
cellchat_netP=data.frame(cellchat@netP,row.names = F)   #不懂为啥提示出错，但貌似没问题



#Step7. 计算加和的cell-cell通讯网络
#我们可以通过计算links数或总结细胞通讯概率来计算加和的cell-cell通讯网络。用户还可以通过设置sources.use 和targets.use来计算细胞亚群之间的加和网络。
cellchat <- aggregateNet(cellchat)


#然后，我们还可以可视化加和的细胞间通讯网络。例如，使用circle plot显示任意两个细胞亚群之间的通讯次数或总通讯强度(权重)：
groupSize <- as.numeric(table(cellchat@idents))

par(mfrow = c(1,2), xpd=TRUE)
netVisual_circle(cellchat@net$count, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F,
                 title.name = "Number of interactions")
netVisual_circle(cellchat@net$weight, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F,
                 title.name = "Interaction weights/strength")

pdf(file="全部细胞互作、细胞通讯 AS.pdf",width=14,height=7)              #保存细胞细胞互作、细胞通讯图片
par(mfrow = c(1,2), xpd=TRUE)
interaction数量=netVisual_circle(cellchat@net$count, vertex.weight = groupSize,
                               weight.scale = T, label.edge= F,
                               title.name = "Number of interactions")
interaction权重=netVisual_circle(cellchat@net$weight, vertex.weight = groupSize,
                               weight.scale = T, label.edge= F,
                               title.name = "Interaction weights/strength")
CombinePlots(plots = c(interaction数量, interaction权重))
dev.off()



#由于细胞间通讯网络的复杂性，我们可以对每个细胞亚群发出的信号进行检测。
#根据细胞互作数量绘制图片
pdf(file="单个细胞间互作、细胞通讯 数量.pdf",width=15,height=15)              #保存细胞细胞互作、细胞通讯图片
mat <- cellchat@net$count
par(mfrow = c(4,3), xpd=TRUE)
for (i in 1:nrow(mat)) {
  mat2 <- matrix(0, nrow = nrow(mat), ncol = ncol(mat), dimnames = dimnames(mat))
  mat2[i, ] <- mat[i, ]
  netVisual_circle(mat2, vertex.weight = groupSize,
                   weight.scale = T, edge.weight.max = max(mat),
                   title.name = rownames(mat)[i])}
dev.off()

#根据细胞互作权重绘制图片
pdf(file="单个细胞间互作、细胞通讯 权重.pdf",width=15,height=15)              #保存细胞细胞互作、细胞通讯图片
mat <- cellchat@net$weight
par(mfrow = c(4,3), xpd=TRUE)
for (i in 1:nrow(mat)) {
  mat2 <- matrix(0, nrow = nrow(mat), ncol = ncol(mat), dimnames = dimnames(mat))
  mat2[i, ] <- mat[i, ]
  netVisual_circle(mat2, vertex.weight = groupSize,
                   weight.scale = T, edge.weight.max = max(mat),
                   title.name = rownames(mat)[i])}
dev.off()




#MIF通路
#Part III：细胞-细胞通讯网络可视化
#Step8. 使用层次图（Hierarchical plot），圆圈图（Circle plot）或和弦图（Chord diagram）可视化每个信号通路
View(df.pathway)  #查看有哪些通路
pathways.show <- c("MIF")   #选择通路感兴趣的通路
levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="MIF通路细胞通讯   层次图  树突细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(2,3,9) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="MIF通路细胞通讯   层次图  T细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(6,7,4,10) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

#绘制圆圈图 Circle plot show pathway
pdf(file="MIF通路细胞通讯   圆圈图.pdf",width=18,height=8)  
par(mfrow=c(1,2))
a=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle")
b=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle",label.edge= T)
CombinePlots(plots = c(a, b))
dev.off()

levels(cellchat@idents) #查看各数值为什么细胞
#绘制和弦图 Circle plot show L-R pairs
pdf(file="MIF MIF_CD74_CXCR4 通路细胞通讯   和弦图.pdf",width=10,height=8)
pairLR.CXCL <- extractEnrichedLR(cellchat, signaling = pathways.show, geneLR.return = F)  
#geneLR.return：一个布尔值参数，用于确定是否返回基因的逻辑回归结果。如果设置为 TRUE，则返回基因的 LR 结果；如果设置为 FALSE，则不返回基因的结果。
LR.show <- pairLR.CXCL[1,] #显示一对配体-受体
LR.show
#"MIF_CD74_CXCR4"
# Vis
netVisual_individual(cellchat, signaling = pathways.show,  pairLR.use = "MIF_CD74_CXCR4", layout = "circle")
dev.off()

#Heatmap：热图说的东西其实和上面展示的是差不多的，只是换了另外一种展现形式。
# Heatmap
pdf(file="MIF细胞通路 全部细胞通讯热图.pdf",width=10,height=8)
par(mfrow=c(1,1))
netVisual_heatmap(cellchat, signaling = pathways.show, color.heatmap = "Reds")
dev.off()

#Step12. 使用小提琴/气泡图绘制信号基因表达分布
pdf(file="MIF细胞通路细胞通讯  小提琴图绘制信号基因表达分布.pdf",width=10,height=8)
plotGeneExpression(cellchat, signaling = "MIF")
dev.off()




#MHC-I通路
#Part III：细胞-细胞通讯网络可视化
#Step8. 使用层次图（Hierarchical plot），圆圈图（Circle plot）或和弦图（Chord diagram）可视化每个信号通路
View(df.pathway)  #查看有哪些通路
pathways.show <- c("MHC-I")   #选择通路感兴趣的通路
levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="MHC-I通路细胞通讯   层次图  树突细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(2,3,9) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="MHC-I通路细胞通讯   层次图  T细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(6,7,4,10) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

#绘制圆圈图 Circle plot show pathway
pdf(file="MHC-I通路细胞通讯   圆圈图.pdf",width=18,height=8)  
par(mfrow=c(1,2))
a=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle")
b=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle",label.edge= T)
CombinePlots(plots = c(a, b))
dev.off()

#Heatmap：热图说的东西其实和上面展示的是差不多的，只是换了另外一种展现形式。
# Heatmap
pdf(file="MHC-I细胞通路 全部细胞通讯热图.pdf",width=10,height=8)
par(mfrow=c(1,1))
netVisual_heatmap(cellchat, signaling = pathways.show, color.heatmap = "Reds")
dev.off()

#Step12. 使用小提琴/气泡图绘制信号基因表达分布
pdf(file="MHC-I细胞通路细胞通讯  小提琴图绘制信号基因表达分布.pdf",width=10,height=8)
plotGeneExpression(cellchat, signaling = "MHC-I")
dev.off()




#MHC-II通路
#Part III：细胞-细胞通讯网络可视化
#Step8. 使用层次图（Hierarchical plot），圆圈图（Circle plot）或和弦图（Chord diagram）可视化每个信号通路
View(df.pathway)  #查看有哪些通路
pathways.show <- c("MHC-II")   #选择通路感兴趣的通路
levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="MHC-II通路细胞通讯   层次图  树突细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(2,3,9) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="MHC-II通路细胞通讯   层次图  T细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(6,7,4,10) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

#绘制圆圈图 Circle plot show pathway
pdf(file="MHC-II通路细胞通讯   圆圈图.pdf",width=18,height=8)  
par(mfrow=c(1,2))
a=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle")
b=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle",label.edge= T)
CombinePlots(plots = c(a, b))
dev.off()

#Heatmap：热图说的东西其实和上面展示的是差不多的，只是换了另外一种展现形式。
# Heatmap
pdf(file="MHC-II细胞通路 全部细胞通讯热图.pdf",width=10,height=8)
par(mfrow=c(1,1))
netVisual_heatmap(cellchat, signaling = pathways.show, color.heatmap = "Reds")
dev.off()

#Step12. 使用小提琴/气泡图绘制信号基因表达分布
pdf(file="MHC-II细胞通路细胞通讯  小提琴图绘制信号基因表达分布.pdf",width=10,height=8)
plotGeneExpression(cellchat, signaling = "MHC-II")
dev.off()



#CD99通路
#Part III：细胞-细胞通讯网络可视化
#Step8. 使用层次图（Hierarchical plot），圆圈图（Circle plot）或和弦图（Chord diagram）可视化每个信号通路
View(df.pathway)  #查看有哪些通路
pathways.show <- c("CD99")   #选择通路感兴趣的通路
levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="CD99通路细胞通讯   层次图  树突细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(2,3,9) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="CD99通路细胞通讯   层次图  T细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(6,7,4,10) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

#绘制圆圈图 Circle plot show pathway
pdf(file="CD99通路细胞通讯   圆圈图.pdf",width=18,height=8)  
par(mfrow=c(1,2))
a=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle")
b=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle",label.edge= T)
CombinePlots(plots = c(a, b))
dev.off()

#Heatmap：热图说的东西其实和上面展示的是差不多的，只是换了另外一种展现形式。
# Heatmap
pdf(file="CD99细胞通路 全部细胞通讯热图.pdf",width=10,height=8)
par(mfrow=c(1,1))
netVisual_heatmap(cellchat, signaling = pathways.show, color.heatmap = "Reds")
dev.off()

#Step12. 使用小提琴/气泡图绘制信号基因表达分布
pdf(file="CD99细胞通路细胞通讯  小提琴图绘制信号基因表达分布.pdf",width=10,height=8)
plotGeneExpression(cellchat, signaling = "CD99")
dev.off()




#ADGRE5通路
#Part III：细胞-细胞通讯网络可视化
#Step8. 使用层次图（Hierarchical plot），圆圈图（Circle plot）或和弦图（Chord diagram）可视化每个信号通路
View(df.pathway)  #查看有哪些通路
pathways.show <- c("ADGRE5")   #选择通路感兴趣的通路
levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="ADGRE5通路细胞通讯   层次图  树突细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(2,3,9) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="ADGRE5通路细胞通讯   层次图  T细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(6,7,4,10) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

#绘制圆圈图 Circle plot show pathway
pdf(file="ADGRE5通路细胞通讯   圆圈图.pdf",width=18,height=8)  
par(mfrow=c(1,2))
a=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle")
b=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle",label.edge= T)
CombinePlots(plots = c(a, b))
dev.off()

#Heatmap：热图说的东西其实和上面展示的是差不多的，只是换了另外一种展现形式。
# Heatmap
pdf(file="ADGRE5细胞通路 全部细胞通讯热图.pdf",width=10,height=8)
par(mfrow=c(1,1))
netVisual_heatmap(cellchat, signaling = pathways.show, color.heatmap = "Reds")
dev.off()

#Step12. 使用小提琴/气泡图绘制信号基因表达分布
pdf(file="ADGRE5细胞通路细胞通讯  小提琴图绘制信号基因表达分布.pdf",width=10,height=8)
plotGeneExpression(cellchat, signaling = "ADGRE5")
dev.off()




#SELPLG通路
#Part III：细胞-细胞通讯网络可视化
#Step8. 使用层次图（Hierarchical plot），圆圈图（Circle plot）或和弦图（Chord diagram）可视化每个信号通路
View(df.pathway)  #查看有哪些通路
pathways.show <- c("SELPLG")   #选择通路感兴趣的通路
levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="SELPLG通路细胞通讯   层次图  树突细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(2,3,9) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="SELPLG通路细胞通讯   层次图  T细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(6,7,4,10) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

#绘制圆圈图 Circle plot show pathway
pdf(file="SELPLG通路细胞通讯   圆圈图.pdf",width=18,height=8)  
par(mfrow=c(1,2))
a=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle")
b=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle",label.edge= T)
CombinePlots(plots = c(a, b))
dev.off()

#Heatmap：热图说的东西其实和上面展示的是差不多的，只是换了另外一种展现形式。
# Heatmap
pdf(file="SELPLG细胞通路 全部细胞通讯热图.pdf",width=10,height=8)
par(mfrow=c(1,1))
netVisual_heatmap(cellchat, signaling = pathways.show, color.heatmap = "Reds")
dev.off()

#Step12. 使用小提琴/气泡图绘制信号基因表达分布
pdf(file="SELPLG细胞通路细胞通讯  小提琴图绘制信号基因表达分布.pdf",width=10,height=8)
plotGeneExpression(cellchat, signaling = "SELPLG")
dev.off()


#ITGB2通路
#Part III：细胞-细胞通讯网络可视化
#Step8. 使用层次图（Hierarchical plot），圆圈图（Circle plot）或和弦图（Chord diagram）可视化每个信号通路
View(df.pathway)  #查看有哪些通路
pathways.show <- c("ITGB2")   #选择通路感兴趣的通路
levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="ITGB2通路细胞通讯   层次图  树突细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(2,3,9) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="ITGB2通路细胞通讯   层次图  T细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(6,7,4,10) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

#绘制圆圈图 Circle plot show pathway
pdf(file="ITGB2通路细胞通讯   圆圈图.pdf",width=18,height=8)  
par(mfrow=c(1,2))
a=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle")
b=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle",label.edge= T)
CombinePlots(plots = c(a, b))
dev.off()

#Heatmap：热图说的东西其实和上面展示的是差不多的，只是换了另外一种展现形式。
# Heatmap
pdf(file="ITGB2细胞通路 全部细胞通讯热图.pdf",width=10,height=8)
par(mfrow=c(1,1))
netVisual_heatmap(cellchat, signaling = pathways.show, color.heatmap = "Reds")
dev.off()

#Step12. 使用小提琴/气泡图绘制信号基因表达分布
pdf(file="ITGB2细胞通路细胞通讯  小提琴图绘制信号基因表达分布.pdf",width=10,height=8)
plotGeneExpression(cellchat, signaling = "ITGB2")
dev.off()



#IL16通路
#Part III：细胞-细胞通讯网络可视化
#Step8. 使用层次图（Hierarchical plot），圆圈图（Circle plot）或和弦图（Chord diagram）可视化每个信号通路
View(df.pathway)  #查看有哪些通路
pathways.show <- c("IL16")   #选择通路感兴趣的通路
levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="IL16通路细胞通讯   层次图  树突细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(2,3,9) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="IL16通路细胞通讯   层次图  T细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(6,7,4,10) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

#绘制圆圈图 Circle plot show pathway
pdf(file="IL16通路细胞通讯   圆圈图.pdf",width=18,height=8)  
par(mfrow=c(1,2))
a=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle")
b=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle",label.edge= T)
CombinePlots(plots = c(a, b))
dev.off()

#Heatmap：热图说的东西其实和上面展示的是差不多的，只是换了另外一种展现形式。
# Heatmap
pdf(file="IL16细胞通路 全部细胞通讯热图.pdf",width=10,height=8)
par(mfrow=c(1,1))
netVisual_heatmap(cellchat, signaling = pathways.show, color.heatmap = "Reds")
dev.off()

#Step12. 使用小提琴/气泡图绘制信号基因表达分布
pdf(file="IL16细胞通路细胞通讯  小提琴图绘制信号基因表达分布.pdf",width=10,height=8)
plotGeneExpression(cellchat, signaling = "IL16")
dev.off()






#TGFb通路
#Part III：细胞-细胞通讯网络可视化
#Step8. 使用层次图（Hierarchical plot），圆圈图（Circle plot）或和弦图（Chord diagram）可视化每个信号通路
View(df.pathway)  #查看有哪些通路
pathways.show <- c("TGFb")   #选择通路感兴趣的通路
levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="TGFb通路细胞通讯   层次图  树突细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(2,3,9) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

levels(cellchat@idents) #查看各数值为什么细胞
# 绘制层次图Hierarchical plot
pdf(file="TGFb通路细胞通讯   层次图  T细胞.pdf",width=18,height=8)  
# 们定义了“顶点.接收”，因此层次图的左侧部分显示向成纤维细胞的信号，右侧部分显示向免疫细胞的信号
vertex.receiver = c(6,7,4,10) # 选择细胞
netVisual_aggregate(cellchat, signaling = pathways.show,  vertex.receiver = vertex.receiver, layout = "hierarchy")
dev.off()

#绘制圆圈图 Circle plot show pathway
pdf(file="TGFb通路细胞通讯   圆圈图.pdf",width=18,height=8)  
par(mfrow=c(1,2))
a=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle")
b=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "circle",label.edge= T)
CombinePlots(plots = c(a, b))
dev.off()

#Heatmap：热图说的东西其实和上面展示的是差不多的，只是换了另外一种展现形式。
# Heatmap
pdf(file="TGFb细胞通路 全部细胞通讯热图.pdf",width=10,height=8)
par(mfrow=c(1,1))
netVisual_heatmap(cellchat, signaling = pathways.show, color.heatmap = "Reds")
dev.off()

#Step12. 使用小提琴/气泡图绘制信号基因表达分布
pdf(file="TGFb细胞通路细胞通讯  小提琴图绘制信号基因表达分布.pdf",width=10,height=8)
plotGeneExpression(cellchat, signaling = "TGFb")
dev.off()








######以下不用绘图


#CellChat的和弦图有两种展示方式：
#一种是netVisual_chord_cell函数，用于可视化不同细胞亚群之间的细胞-细胞通讯（弦图中的每个扇区都是一个细胞亚群）；
#而netVisual_chord_gene函数，用于显示由多个配体-受体或信号通路（弦图中的每个扇区是一个配体、受体或信号通路）介导的细胞-细胞通讯。
pdf(file="MIF  两种和弦图.pdf",width=20,height=16)
par(mfrow = c(1,2), xpd=TRUE)
# Chord diagram 下面这两幅图等价
c=netVisual_aggregate(cellchat, signaling = pathways.show, layout = "chord",title.name = "Chord diagram  1",point.size=1)
d=netVisual_chord_cell(cellchat, signaling = pathways.show,title.name = "Chord diagram  2: show cell type",)
CombinePlots(plots = c(c, d))
dev.off()

levels(cellchat@idents) #查看各数值为什么细胞
# Chord diagram 2 show L-R pairs 显示配受体层面的和弦图，指定slot.name为net
pdf(file="细胞通路 和弦图.pdf",width=10,height=10)
netVisual_chord_gene(cellchat, sources.use = 1, targets.use = c(5:8), lab.cex = 0.5,title.name = "Chord diagram  2: show gene",slot.name = "net") 
dev.off()

# Chord diagram 3 show pathway 显示通路层面的和弦图，指定slot.name为netP
netVisual_chord_gene(cellchat, sources.use = 1, targets.use = c(5:8), lab.cex = 0.5,slot.name = "netP",title.name = "Chord diagram  2: show pathway") 


#对于和弦图，CellChat有一个独立的功能netVisual_chord_cell，通过调整圆包中的不同参数，可以灵活地可视化信号网络。
#例如，我们可以定义一个命名字符向量组来创建多组和弦图，例如，将cell集群分组为不同的cell类型。
levels(cellchat@idents)

### 合并细胞类型
group.cellType <- c("T","T","Mono","B","T","Mono","NK","DC","Platelet")
group.cellType <- factor(group.cellType, levels = c("T", "B", "Mono", "NK","DC","Platelet"))
names(group.cellType) <- levels(cellchat@idents)

# Vis
netVisual_chord_cell(cellchat, signaling = pathways.show, group = group.cellType, title.name = paste0(pathways.show, " signaling network"))


#Heatmap：热图说的东西其实和上面展示的是差不多的，只是换了另外一种展现形式。
# Heatmap
pdf(file="MIF细胞通路 全部细胞通讯热图.pdf",width=10,height=8)
par(mfrow=c(1,1))
netVisual_heatmap(cellchat, signaling = pathways.show, color.heatmap = "Reds")
dev.off()

#Step9. 计算每个配体-受体对L-R pairs对整个信号通路的贡献，并可视化单个配体-受体对介导的细胞-细胞通信

netAnalysis_contribution(cellchat, signaling = pathways.show)

#我们还可以可视化到单个配体-受体对介导的细胞-细胞通信。我们还可以用Circle plot show L-R pairs（见Step8），
#即可视化单个配体-受体对介导的细胞-细胞通信。作者提供了一个函数 extractEnrichedLR ，用于提取指定信号通路的所有L-R pairs和相关信号基因。
#除了Circle plot可视化受配体对，还可以用和弦图，逻辑和可视化pathwaty是一样的，无非是多指定一个pairLR.use：

# Chord diagram
netVisual_individual(cellchat, signaling = pathways.show, pairLR.use = "MIF_CD74_CXCR4", layout = "chord")


#Step10.自动保存所有推断网络，方便用户快速探索
#在实际使用中，用户可以使用for循环来自动保存所有推测的网络，以便使用netVisual进行快速探索。
#netVisual支持svg、png和pdf格式的输出，这里包括了两种可视化方法，一个是hierarchy plot，另一个是柱状图，见gg.plot的输出结果：

#netVisual.V2函数是生信技能树根据netVisual函数进行改编。需要得到netVisual.V2函数才能完成Step10


# Access all the signaling pathways showing significant communications
pathways.show.all <- cellchat@netP$pathways
# check the order of cell identity to set suitable vertex.receiver
levels(cellchat@idents)
vertex.receiver = seq(1,4)
# Vis
gg.list = list()
for (i in 1:length(pathways.show.all)) {
  ## 可视化1：hierarchy plot 可视化配受体对 netVisual.V2是在作者的netVisual基础上补充了out.dir参数
  # Visualize communication network associated with both signaling pathway and individual L-R pairs
  netVisual.V2(cellchat, signaling = pathways.show.all[i],
               vertex.receiver = vertex.receiver, layout = "hierarchy",out.dir = "./NetVisual/")
  
  ## 可视化2： 柱状图可视化配受体对 
  # Compute and visualize the contribution of each ligand-receptor pair to the overall signaling pathway
  gg <- netAnalysis_contribution(cellchat, signaling = pathways.show.all[i])
  gg.list[[pathways.show.all[i]]] = gg
  #ggsave(filename=paste0(pathways.show.all[i], "_L-R_contribution.pdf"), plot=gg, width = 3, height = 2, units = 'in', dpi = 300)
}
gg.plot = wrap_plots(gg.list,ncol = 5)
gg.plot

ggsave(gg.plot,filename = "./_L-R_contribution.pdf")

dev.off()



#############以上代码不用运行绘图




levels(cellchat@idents)
#Step11. 观察多种配体受体或信号通路介导的细胞-细胞通讯  主要有气泡图、和弦图和小提琴图三种可视化方式：
#11.1 气泡图  展示指定sources.use和targets.use的所有的配受体信息
### Bubble plot
# show all the significant interactions (L-R pairs) from some cell groups (defined by 'sources.use') to other cell groups (defined by 'targets.use')
pdf(file="单细胞与其他细胞互作B cell与其他全部细胞通讯及相关通路气泡图.pdf",width=5,height=10)
netVisual_bubble(cellchat, sources.use = 1, targets.use = c(2:10), remove.isolate = FALSE)  #选择第一个细胞，与剩余2到8个细胞，之间的关系。remove.isolate = FALSE为是否删除孤立的细胞，即与其他细胞没有互作的
dev.off()

levels(cellchat@idents)
pdf(file="单细胞与其他细胞互作 CD141+CLEC9A+ dendritic cell与其他全部细胞通讯及相关通路气泡图.pdf",width=5,height=10)
netVisual_bubble(cellchat, sources.use = 2, targets.use = c(1,3:10), remove.isolate = FALSE)  #选择第一个细胞，与剩余2到8个细胞，之间的关系。remove.isolate = FALSE为是否删除孤立的细胞，即与其他细胞没有互作的
dev.off()

levels(cellchat@idents)
pdf(file="单细胞与其他细胞互作CD1C-CD141- dendritic cell与其他全部细胞通讯及相关通路气泡图.pdf",width=5,height=10)
netVisual_bubble(cellchat, sources.use = 3, targets.use = c(1:2,4:10), remove.isolate = FALSE)  #选择第一个细胞，与剩余2到8个细胞，之间的关系。remove.isolate = FALSE为是否删除孤立的细胞，即与其他细胞没有互作的
dev.off()

levels(cellchat@idents)
pdf(file="单细胞与其他细胞互作 Effector CD8+ memory T (Tem) cell与其他全部细胞通讯及相关通路气泡图.pdf",width=5,height=10)
netVisual_bubble(cellchat, sources.use = 4, targets.use = c(1:3,5:10), remove.isolate = FALSE)  #选择第一个细胞，与剩余2到8个细胞，之间的关系。remove.isolate = FALSE为是否删除孤立的细胞，即与其他细胞没有互作的
dev.off()

levels(cellchat@idents)
pdf(file="单细胞与其他细胞互作 M2 macrophage细胞与其他全部细胞通讯及相关通路气泡图.pdf",width=5,height=10)
netVisual_bubble(cellchat, sources.use = 5, targets.use = c(1:4,6:10), remove.isolate = FALSE)  #选择第一个细胞，与剩余2到8个细胞，之间的关系。remove.isolate = FALSE为是否删除孤立的细胞，即与其他细胞没有互作的
dev.off()

levels(cellchat@idents)
pdf(file="单细胞与其他细胞互作Naive CD4+ T cell细胞与其他全部细胞通讯及相关通路气泡图.pdf",width=5,height=10)
netVisual_bubble(cellchat, sources.use = 6, targets.use = c(1:5,7:10), remove.isolate = FALSE)  #选择第一个细胞，与剩余2到8个细胞，之间的关系。remove.isolate = FALSE为是否删除孤立的细胞，即与其他细胞没有互作的
dev.off()

levels(cellchat@idents)
pdf(file="单细胞与其他细胞互作Naive CD8+ T cell与其他全部细胞通讯及相关通路气泡图.pdf",width=5,height=10)
netVisual_bubble(cellchat, sources.use = 7, targets.use = c(1:6,8:10), remove.isolate = FALSE)  #选择第一个细胞，与剩余2到8个细胞，之间的关系。remove.isolate = FALSE为是否删除孤立的细胞，即与其他细胞没有互作的
dev.off()

levels(cellchat@idents)
pdf(file="单细胞与其他细胞互作Natural killer cell与其他全部细胞通讯及相关通路气泡图.pdf",width=5,height=10)
netVisual_bubble(cellchat, sources.use = 8, targets.use = c(1:7,9:10), remove.isolate = FALSE)  #选择第一个细胞，与剩余2到8个细胞，之间的关系。remove.isolate = FALSE为是否删除孤立的细胞，即与其他细胞没有互作的
dev.off()


levels(cellchat@idents)
pdf(file="单细胞与其他细胞互作Plasmacytoid dendritic cell与其他全部细胞通讯及相关通路气泡图.pdf",width=5,height=10)
netVisual_bubble(cellchat, sources.use = 9, targets.use = c(1:8,10), remove.isolate = FALSE)  #选择第一个细胞，与剩余2到8个细胞，之间的关系。remove.isolate = FALSE为是否删除孤立的细胞，即与其他细胞没有互作的
dev.off()


levels(cellchat@idents)
pdf(file="单细胞与其他细胞互作T helper1 (Th1) cell与其他全部细胞通讯及相关通路气泡图.pdf",width=5,height=10)
netVisual_bubble(cellchat, sources.use = 10, targets.use = c(1:9), remove.isolate = FALSE)  #选择第一个细胞，与剩余2到8个细胞，之间的关系。remove.isolate = FALSE为是否删除孤立的细胞，即与其他细胞没有互作的
dev.off()




##########以下代码不用运行


#展示指定sources.use和targets.use的指定的pathway下的配受体信息，signaling参数
# show all the significant interactions (L-R pairs) associated with certain signaling pathways
netVisual_bubble(cellchat, sources.use = 1, targets.use = c(2:10), 
                 signaling = c("MIF","MHC-I"), remove.isolate = FALSE)

#展示指定sources.use和targets.use的指定的配受体信息，pairLR.use参数
pairLR.use <- extractEnrichedLR(cellchat, signaling = c("MIF","MHC-I"))
pairLR.use  = pairLR.use[c(1,8),,drop=F]
netVisual_bubble(cellchat, sources.use = c(1), targets.use = c(2:7), 
                 pairLR.use = pairLR.use, remove.isolate = T)


#11.2 和弦图  同样的，基于netVisual_chord_gene函数，也可以用和弦图进行可视化：
#展示从一些细胞群到其他细胞群的所有相互作用（受配体对或pathway)。两种特殊情况：
#一种是展示从一个细胞亚群发送的所有相互作用，另一种是显示由一个一个细胞亚群接收的所有相互作用；
#展示用户自定义的某些信号通路。如下：
#第一种情况，展示所有的指定的细胞亚群之间的相互作用通路：例如native CD4T接受其他细胞的信号
levels(cellchat@idents)
#显示来自'sources.use'到'targets.use'的所有显著互作
pdf(file="Tissue_stem_cells细胞细胞与其他全部细胞通讯及相关通路和弦图.pdf",width=10,height=8)
netVisual_chord_gene(cellchat,
                     sources.use = 8,
                     targets.use = c(1:7),
                     lab.cex = 0.5,legend.pos.y = 30)
dev.off()

#或者native CD4T传到其他细胞的信号：
# show all the interactions received by native CD4T
netVisual_chord_gene(cellchat,
                     sources.use = c(2:5),
                     targets.use = 1,
                     legend.pos.x = 15)



#用户也可以通过slot.name = "netP"显示所有的通路，或者在此基础上加signaling参数指定特定通路：
# show all the significant signaling pathways from some cell groups (defined by 'sources.use') to other cell groups (defined by 'targets.use')
netVisual_chord_gene(cellchat,
                     sources.use = c(1),
                     targets.use = c(2:7),
                     slot.name = "netP", legend.pos.x = 10)

## 体会与上代码的区别？
netVisual_chord_gene(cellchat,
                     sources.use = c(1),
                     targets.use = c(2:7),signaling = c("MIF","MHC-I"),
                     slot.name = "netP", legend.pos.x = 10)



#用户也可以通过signaling指定需要展示的特定通路下的受配体对，以及用pairLR.use指定需要展示的受配体对：
# show all the significant interactions (L-R pairs) associated with certain signaling pathways
netVisual_chord_gene(cellchat, sources.use = c(1),
                     targets.use = c(2:7),
                     signaling = c("MIF","MHC-I"),
                     legend.pos.x = 8)

# show specific interactions (L-R pairs) associated with certain signaling pathways
pairLR.use <- extractEnrichedLR(cellchat, signaling = c("MIF","MHC-I"))
pairLR.use  = pairLR.use[c(1,3),,drop=F]
netVisual_chord_gene(cellchat, sources.use = c(1),
                     targets.use = c(2:7),
                     pairLR.use = pairLR.use,
                     # signaling = c("MIF","MHC-I"),
                     legend.pos.x = 8)


#Step12. 使用小提琴/气泡图绘制信号基因表达分布
plotGeneExpression(cellchat, signaling = "MIF")

#默认情况下，plotGeneExpression只显示与推测的显著的通讯相关的信号基因的表达。用户可以展示某通路下所有的受配体信号：
plotGeneExpression(cellchat, signaling = "CXCL", enriched.only = FALSE)
#用户也可以使用extractEnrichedLR提取推测的受配体对或信号通路相关的信号基因，然后使用Seurat包绘制基因表达图。



###########以上代码不用运行


#Part IV: 细胞-细胞通讯网络的系统分析
#Step13. 识别细胞亚群的信号作用（例如主要的发送者，接收者）以及主要的贡献信号

#13.1 计算并可视化网络中心性得分
#netAnalysis_computeCentrality函数基于netP插槽，计算网络中心性得分，然后进行可视化：

# Compute the network centrality scores
cellchat <- netAnalysis_computeCentrality(cellchat, slot.name = "netP") # the slot 'netP' means the inferred intercellular communication network of signaling pathways
# 使用热图可视化计算的中心性分数，便于快速识别细胞组的主要信号传导作用
cellchat@netP$pathways


pathways.show = "CD99"
pdf(file="CD99通路所有细胞中心评分热图可视化.pdf",width=5,height=3)
netAnalysis_signalingRole_network(cellchat,
                                  signaling = pathways.show,
                                  width = 8, height = 2.5,
                                  font.size = 10)
dev.off()

pathways.show = "MIF"
pdf(file="MIF通路所有细胞中心评分热图可视化.pdf",width=5,height=3)
netAnalysis_signalingRole_network(cellchat,
                                  signaling = pathways.show,
                                  width = 8, height = 2.5,
                                  font.size = 10)
dev.off()

pathways.show = "MHC-I"
pdf(file="MHC-I通路所有细胞中心评分热图可视化.pdf",width=5,height=3)
netAnalysis_signalingRole_network(cellchat,
                                  signaling = pathways.show,
                                  width = 8, height = 2.5,
                                  font.size = 10)
dev.off()

pathways.show = "ADGRE5"
pdf(file="ADGRE5通路所有细胞中心评分热图可视化.pdf",width=5,height=3)
netAnalysis_signalingRole_network(cellchat,
                                  signaling = pathways.show,
                                  width = 8, height = 2.5,
                                  font.size = 10)
dev.off()

pathways.show = "SELPLG"
pdf(file="SELPLG通路所有细胞中心评分热图可视化.pdf",width=5,height=3)
netAnalysis_signalingRole_network(cellchat,
                                  signaling = pathways.show,
                                  width = 8, height = 2.5,
                                  font.size = 10)
dev.off()


pathways.show = "ITGB2"
pdf(file="ITGB2通路所有细胞中心评分热图可视化.pdf",width=5,height=3)
netAnalysis_signalingRole_network(cellchat,
                                  signaling = pathways.show,
                                  width = 8, height = 2.5,
                                  font.size = 10)
dev.off()

pathways.show = "IL16"
pdf(file="IL16通路所有细胞中心评分热图可视化.pdf",width=5,height=3)
netAnalysis_signalingRole_network(cellchat,
                                  signaling = pathways.show,
                                  width = 8, height = 2.5,
                                  font.size = 10)
dev.off()


pathways.show = "TGFb"
pdf(file="TGFb通路所有细胞中心评分热图可视化.pdf",width=5,height=3)
netAnalysis_signalingRole_network(cellchat,
                                  signaling = pathways.show,
                                  width = 8, height = 2.5,
                                  font.size = 10)
dev.off()


pathways.show = "ICAM"
pdf(file="ICAM通路所有细胞中心评分热图可视化.pdf",width=5,height=3)
netAnalysis_signalingRole_network(cellchat,
                                  signaling = pathways.show,
                                  width = 8, height = 2.5,
                                  font.size = 10)
dev.off()


pathways.show = "MHC-II"
pdf(file="MHC-II通路所有细胞中心评分热图可视化.pdf",width=5,height=3)
netAnalysis_signalingRole_network(cellchat,
                                  signaling = pathways.show,
                                  width = 8, height = 2.5,
                                  font.size = 10)
dev.off()




############以下代码不用运行






#13.2 在2D空间中可视化主要的发送者（source）和接收者（target）
#作者还提供了另一种直观的方法，使用散点图在2D空间中可视化主要的发送方(source)和接收方(target)：

# 对来自所有信号通路的综合细胞间通信网络进行信号传导角色分析
gg1 <- netAnalysis_signalingRole_scatter(cellchat)+ggtitle("All pathway")

## 感兴趣的pathway
# Signaling role analysis on the cell-cell communication networks of interest
gg2 <- netAnalysis_signalingRole_scatter(cellchat, signaling = c("MIF","MHC-I"))+ggtitle("MIF and MHC-I")
par(mfrow = c(1,2), xpd=TRUE)
pdf(file="全部细胞通路、感兴趣的细胞通路气泡图.pdf",width=10,height=6)  
gg1 + gg2
CombinePlots(plots = c(gg1, gg2))
dev.off()

############以上代码不用运行


pdf(file="所有信号通路的综合细胞间通信网络进行信号传导角色分析.pdf",width=8,height=6)  
netAnalysis_signalingRole_scatter(cellchat)+ggtitle("All pathway")
dev.off()



############以下代码不用运行


https://mp.weixin.qq.com/s/z4H5gjI5TIf-u19ZMrSB2w
13.3 识别对某些细胞亚群的输出或输入信号中贡献最大的信号
# Signaling role analysis on the aggregated cell-cell communication network from all signaling pathways
ht1 <- netAnalysis_signalingRole_heatmap(cellchat, pattern = "outgoing")
ht2 <- netAnalysis_signalingRole_heatmap(cellchat, pattern = "incoming")
ht1 + ht2





#构建数据框

df =AvailableData()

#循环下载

for (i in 1:length(df$Dataset)) {
  
  InstallData(df$Dataset[i])
  
} 
devtools::install_github('satijalab/seurat-data') 

install.packages("seuratdata", repo = "http://cran.rstudio.com/")

install.packages("seuratdata")


install.packages("C:\\Users\\Administrator\\Downloads\\ssHippo.SeuratData_3.1.4.tar.gz",type="source",repos=NULL)


install.packages("C:\\Users\\Administrator\\Downloads\\ifnb.SeuratData_3.1.0.tar.gz", repos = NULL, type = "source")
library(ifnb.SeuratData)
LoadData("ifnb")


install.packages("C:\\Users\\Administrator\\Downloads\\seurat-data-master.zip", repos = NULL, type = "source")


usethis::edit_r_environ()



